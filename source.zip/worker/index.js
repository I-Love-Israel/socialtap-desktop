const origin='https://www.socialtap.social';
const allowed={'/api/login':['POST'],'/api/logout':['POST'],'/messages':['GET'],'/send':['POST'],'/api/chats':['GET'],'/api/chats/create':['POST'],'/api/settings':['GET'],'/settings/toggle-global-chat':['POST'],'/api/user/lookupuseridbyusername':['GET'],'/api/user/presence':['GET','POST']};
const jsonError=(error,status)=>Response.json({error},{status,headers:{'Cache-Control':'no-store'}});
const oauthConfig={"client_id":"stu_peEhYlyqT3RP2Yi2mXGRaaUuZjg9utL_LbhlE6Psuqs","issuer":"https://www.socialtap.social","authorization_endpoint":"https://www.socialtap.social/api/oauth/authorize","redirect_uris":["https://socialtap-blue-white-client.rightpeach69.chatgpt.site/oauth/callback","http://127.0.0.1:4317/oauth/callback"]};
const oauthRoutes={'/api/chats':['GET'],'/messages':['GET'],'/send':['POST']};
async function authRoute(req,u){
 const redirect=u.origin+'/oauth/callback';
 if(!oauthConfig.redirect_uris.includes(redirect))return jsonError('This client address is not registered.',403);
 if(u.pathname==='/auth/config'&&req.method==='GET')return Response.json({...oauthConfig,redirect_uri:redirect,scope:'chat.read chat.send'},{headers:{'Cache-Control':'no-store'}});
 if(!['/auth/token','/auth/revoke'].includes(u.pathname)||req.method!=='POST')return jsonError('Unsupported request',405);
 if(req.headers.get('origin')!==u.origin)return jsonError('Invalid origin',403);
 if(!req.headers.get('content-type')?.startsWith('application/x-www-form-urlencoded'))return jsonError('Form encoding required',415);
 try{
  const raw=await req.text();if(raw.length>16384)return jsonError('Request too large',413);
  const input=new URLSearchParams(raw),body=new URLSearchParams({client_id:oauthConfig.client_id});
  if([...input.keys()].some(k=>input.getAll(k).length!==1))return jsonError('Duplicate parameters',400);
  if(input.has('client_id')&&input.get('client_id')!==oauthConfig.client_id)return jsonError('Invalid client',400);
  const revoke=u.pathname==='/auth/revoke';
  if(revoke){if(!input.get('token'))return jsonError('Token required',400);body.set('token',input.get('token'));}
  else{
   const grant=input.get('grant_type');body.set('grant_type',grant||'');
   if(grant==='authorization_code'){
    if(input.get('redirect_uri')!==redirect||!input.get('code')||!/^[A-Za-z0-9._~-]{43,128}$/.test(input.get('code_verifier')||''))return jsonError('Invalid sign-in exchange',400);
    for(const key of ['code','code_verifier'])body.set(key,input.get(key));body.set('redirect_uri',redirect);
   }else if(grant==='refresh_token'){if(!input.get('refresh_token'))return jsonError('Refresh token required',400);body.set('refresh_token',input.get('refresh_token'));}
   else return jsonError('Unsupported grant',400);
  }
  const r=await fetch(origin+(revoke?'/api/oauth/revoke':'/api/oauth/token'),{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',Accept:'application/json'},body:body.toString(),redirect:'manual',signal:AbortSignal.timeout(20000)});
  if(revoke&&r.ok)return Response.json({success:true},{headers:{'Cache-Control':'no-store'}});
  if(!r.headers.get('content-type')?.includes('json'))return jsonError('SocialTap could not complete authorization.',502);
  return new Response(await r.text(),{status:r.status,headers:{'Content-Type':'application/json','Cache-Control':'no-store','Pragma':'no-cache'}});
 }catch{return jsonError('Cannot reach SocialTap authorization. Please reconnect.',502);}
}
export default {
 async fetch(req){
  const u=new URL(req.url);
  if(u.pathname.startsWith('/auth/'))return authRoute(req,u);
  if(u.pathname.startsWith('/bridge/')){
   const path=u.pathname.slice(7);
   if(!allowed[path]?.includes(req.method))return jsonError('Unsupported request',405);
   if(req.method==='POST'&&req.headers.get('origin')!==u.origin)return jsonError('Invalid origin',403);
   try{
    const headers=new Headers({Accept:'application/json',Origin:origin,Referer:origin+'/'});
    const bearer=req.headers.get('authorization');
    if(bearer){if(!/^Bearer [A-Za-z0-9._~+\/-]+=*$/.test(bearer)||!oauthRoutes[path]?.includes(req.method))return jsonError('This action needs the normal SocialTap website.',403);headers.set('Authorization',bearer);}
    const session=(req.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('st_session='));
    if(session&&!bearer)headers.set('Cookie','session='+session.slice(11));
    if(req.headers.has('content-type'))headers.set('Content-Type',req.headers.get('content-type'));
    const body=req.method==='GET'?undefined:await req.text();
    if(body?.length>8192)return jsonError('Request too large',413);
    const response=await fetch(origin+path+u.search,{method:req.method,headers,body,redirect:'manual',signal:AbortSignal.timeout(20000)});
    if(response.status>=300&&response.status<400)return jsonError('Please sign in to SocialTap.',401);
    if(response.status>=500)return jsonError('SocialTap is having a server problem. Please try signing in on the normal SocialTap website, or try again later.',response.status);
    if(!response.headers.get('content-type')?.includes('json'))return jsonError('SocialTap returned an unexpected response. Try again.',502);
    const out=new Headers({'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    for(const cookie of response.headers.getSetCookie()){
     if(bearer||!cookie.startsWith('session='))continue;
     // Keep the upstream session private to this client; never forward hosting cookies.
     let mapped=cookie.replace(/^session=/,'st_session=').replace(/;\s*(Domain|Path|SameSite)=[^;]+/ig,'').replace(/;\s*(HttpOnly|Secure)(?=;|$)/ig,'');
     const loopback=u.protocol==='http:'&&['127.0.0.1','localhost','[::1]'].includes(u.hostname);
     mapped+='; Path=/; SameSite=Strict; HttpOnly'+(loopback?'':'; Secure');
     out.append('Set-Cookie',mapped);
    }
    return new Response(await response.text(),{status:response.status,headers:out});
   }catch{return jsonError('Cannot reach SocialTap. Please try again.',502);}
  }
  if(u.pathname!=='/'&&u.pathname!=='/oauth/callback')return new Response('Not found',{status:404});
  return new Response(page,{headers:{'Content-Type':'text/html; charset=utf-8','Referrer-Policy':'no-referrer','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
 }
};
const page=String.raw`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SocialTap · Blue & White</title><style>
*{box-sizing:border-box}body{margin:0;color:#19304f;font:15px/1.5 system-ui,sans-serif;background:#f8faff}button,input,textarea{font:inherit}button{cursor:pointer}button:disabled{opacity:.5;cursor:not-allowed}button:focus-visible,a:focus-visible{outline:3px solid #7eafff;outline-offset:3px}.flag{position:fixed;inset:0;z-index:-1;background:linear-gradient(#fff 12%,#1754b9 12% 27%,#fff 27% 73%,#1754b9 73% 88%,#fff 88%)}.flag svg{position:absolute;right:-4%;top:27%;width:48%;height:46%;opacity:.22}.top{height:92px;max-width:1300px;margin:auto;padding:0 30px;display:flex;align-items:center;justify-content:space-between}.brand{font-weight:800;font-size:27px;letter-spacing:-1px;display:flex;gap:12px;align-items:center}.mark{background:#1754b9;color:white;border-radius:13px;padding:3px 11px}.eyebrow{font-size:10px;font-weight:750;letter-spacing:2px;text-transform:uppercase;color:#6c809c}.shell{display:grid;grid-template-columns:270px 1fr;max-width:1240px;margin:12px auto 30px;height:calc(100dvh - 142px);min-height:0;background:#ffffffee;border:1px solid #dbe4f2;border-radius:23px;overflow:hidden;box-shadow:0 24px 80px #10295e38}.side{background:#f5f8fc;border-right:1px solid #e0e7f1;padding:26px 20px;display:flex;flex-direction:column;gap:16px}.side h2{font-size:22px;margin:0}.btn{border:1px solid #d7e1ee;border-radius:10px;padding:10px 14px;background:white;color:#2b476e;font-weight:600}.primary{background:#1754b9;border-color:#1754b9;color:white}.rooms{flex:1;overflow:auto}.room{border:0;background:transparent;width:100%;padding:14px 10px;border-radius:12px;text-align:left;display:flex;align-items:center;gap:12px;color:#2b476e;margin:5px 0}.room.active{background:#e4edfc;color:#164da5}.avatar{display:grid;place-items:center;width:40px;height:40px;border-radius:12px;background:#e6edfa;color:#2c58a1;flex:none;font-weight:700}.room strong,.room small{display:block}.room small{color:#7a8aa2;font-size:11px}.foot{border-top:1px solid #dce4ef;padding-top:18px}.muted{font-size:13px;color:#73859c}.main{display:flex;flex-direction:column;min-width:0;min-height:0}.head{border-bottom:1px solid #e4eaf3;padding:22px 28px;display:flex;align-items:center;gap:14px}.head h1{font-size:19px;margin:0}.status{font-size:12px;color:#7b8ba1}.welcome{flex:1;display:grid;grid-template-columns:1fr 1fr;align-items:center;padding:45px;gap:36px}.welcome h1{font-size:40px;line-height:1.17;letter-spacing:-1.6px;margin:18px 0}.welcome p{color:#73859c}.star{color:#1754b9;font-size:40px}.login{padding:26px;border:1px solid #e0e7f1;border-radius:18px;background:white;box-shadow:0 8px 35px #1835670d}.login h2{font-size:21px;margin:0 0 6px}label{display:block;font-size:12px;font-weight:650;margin:18px 0 7px}input,textarea{border:1px solid #d7e1ed;border-radius:9px;padding:12px;width:100%;color:#223d63;background:white}input:focus,textarea:focus{outline:2px solid #abc9fb}.login .btn{width:100%;margin-top:14px}.error{color:#b23131;font-size:13px;min-height:19px}.info{font-size:11px;color:#7d8da2}.link{color:#1754b9;text-decoration:none}.chat{display:flex;flex-direction:column;flex:1;min-height:0}.banner{background:#fff5dd;color:#88692e;padding:8px 28px;font-size:12px}.messages{flex:1;overflow:auto;padding:28px}.message{display:flex;gap:12px;margin-bottom:24px}.message.me{flex-direction:row-reverse}.meta{font-size:11px;color:#798ba4;margin-bottom:6px}.me .meta{text-align:right}.bubble{background:#eff3f9;border-radius:0 14px 14px;padding:12px 16px;white-space:pre-wrap;overflow-wrap:anywhere;max-width:540px}.me .bubble{background:#1754b9;color:white;border-radius:14px 0 14px 14px}.composer{border:1px solid #dce4f0;border-radius:14px;padding:12px;margin:0 25px 22px;background:white}.composer textarea{height:70px;resize:none;border:0;outline:none;padding:5px}.composer footer{display:flex;align-items:center;justify-content:space-between}.notice{padding:0 25px;margin:0;color:#b23131;font-size:13px}.empty{text-align:center;padding:50px;color:#7e8fa5}.hidden{display:none!important}dialog{border:1px solid #dbe3ef;border-radius:18px;padding:28px;width:430px;max-width:95vw;color:#19304f}dialog::backdrop{background:#142d5655;backdrop-filter:blur(3px)}dialog h2{margin-top:0}.actions{display:flex;gap:10px;justify-content:flex-end;margin-top:20px}.mobile{display:none}@media(max-width:1050px){.shell{margin:12px 20px;grid-template-columns:230px 1fr}.welcome{grid-template-columns:1fr;padding:25px;gap:10px;overflow:auto}.intro h1{font-size:28px}.intro p,.star{display:none}}@media(max-width:650px){.top{height:70px;padding:0 18px}.brand .eyebrow{display:none}.shell{margin:0 10px;min-height:0;height:calc(100dvh - 85px);grid-template-columns:1fr}.side{display:none}.shell.showrooms .side{display:flex}.shell.showrooms .main{display:none}.mobile{display:block}.head{padding:16px}.welcome{padding:18px}.login{padding:20px}.messages{padding:16px}.composer{margin:0 12px 12px}.flag svg{width:100%}}
.messages{background:center / 230px no-repeat url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 200 200%27%3E%3Cg fill=%27none%27 stroke=%27%230038b8%27 opacity=%27.06%27 stroke-width=%277%27%3E%3Cpath d=%27M100 18 171 141H29Z%27/%3E%3Cpath d=%27M100 182 29 59H171Z%27/%3E%3C/g%3E%3C/svg%3E")} .google-signin{display:flex;align-items:center;justify-content:center;gap:10px;text-decoration:none;color:#213b60;background:white}.google-signin:hover{background:#f5f8fd;border-color:#a9bfde}.login-divider{display:flex;align-items:center;gap:10px;color:#7889a1;font-size:11px;margin:18px 0 5px}.login-divider:before,.login-divider:after{content:"";height:1px;background:#e1e7ef;flex:1}.welcome{overflow:auto}.login{margin:auto 0} </style></head><body><div class="flag" aria-hidden="true"><svg viewBox="0 0 200 200"><g fill="none" stroke="#0038b8" stroke-width="8"><path d="M100 18 171 141H29Z"/><path d="M100 182 29 59H171Z"/></g></svg></div><header class="top"><div class="brand"><span class="mark">st</span>SocialTap <span class="eyebrow" style="margin-left:12px">Blue & White</span></div><a class="link info" href="https://www.socialtap.social/apidocs" target="_blank" rel="noreferrer">API docs ↗</a></header><div class="shell" id="shell"><aside class="side"><div class="eyebrow">Your space to connect</div><h2>Conversations</h2><button class="btn" id="newchat" disabled>＋ New conversation</button><div class="rooms" id="rooms"></div><div class="foot"><strong id="identity">Welcome to SocialTap</strong><p class="muted" id="identityhint">Sign in to join the conversation.</p><a class="link info hidden" id="official" href="https://www.socialtap.social/" target="_blank" rel="noopener noreferrer">Manage chats & settings on SocialTap ↗</a><button class="btn hidden" id="settings">Settings</button> <button class="btn hidden" id="logout">Sign out</button></div></aside><main class="main"><header class="head"><button class="btn mobile" id="menu" aria-label="Open conversations">☰</button><span class="avatar">#</span><div style="flex:1"><h1 id="title">A little closer, together.</h1><div class="status" id="status">Your SocialTap chat client</div></div><button class="btn hidden" id="refresh" aria-label="Refresh messages">↻</button></header><section class="welcome" id="welcome"><div class="intro"><div class="star">✡</div><div class="eyebrow">Good conversations start here</div><h1>Your people.<br>Your conversations.<br><span style="color:#1754b9">One simple space.</span></h1><p>Catch up with friends, find your community, and stay in the conversation.</p><p class="info">An independent client for SocialTap.<br>Made with a blue-and-white spirit.</p></div><form id="login" class="login"><h2>Welcome back</h2><div class="muted">Sign in with your SocialTap account.</div><button type="button" class="btn google-signin" id="google-signin" aria-describedby="google-help"><svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24"><path fill="#4285F4" d="M21.6 12.23c0-.71-.06-1.39-.18-2.05H12v3.88h5.38a4.6 4.6 0 0 1-2 3.02v2.51h3.24c1.89-1.74 2.98-4.31 2.98-7.36Z"/><path fill="#34A853" d="M12 22c2.7 0 4.96-.9 6.61-2.41l-3.24-2.51c-.9.6-2.05.96-3.37.96-2.61 0-4.82-1.76-5.61-4.12H3.05v2.59A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.39 13.92A6 6 0 0 1 6.08 12c0-.67.11-1.31.31-1.92V7.49H3.05A10 10 0 0 0 2 12c0 1.61.39 3.14 1.05 4.51l3.34-2.59Z"/><path fill="#EA4335" d="M12 5.96c1.47 0 2.79.5 3.82 1.49l2.87-2.87A9.6 9.6 0 0 0 12 2a10 10 0 0 0-8.95 5.49l3.34 2.59C7.18 7.72 9.39 5.96 12 5.96Z"/></svg><span>Connect with SocialTap</span><span aria-hidden="true">↗</span></button><p class="info" id="google-help">Use Google or your password on SocialTap’s secure sign-in page, then return here to your chats. This connection lasts while this tab stays open.</p><p id="loginerror" class="error" role="alert"></p><details><summary class="login-divider" style="cursor:pointer">Use password directly instead</summary><label for="username">Email</label><input id="username" autocomplete="username" type="email" placeholder="Your email address" required><label for="password">Password</label><input id="password" type="password" autocomplete="current-password" placeholder="Enter your password" required><button class="btn primary" id="signin">Sign in →</button></details><div class="info" style="text-align:center;margin-top:16px">Want to look around first?</div><button class="btn" id="demo" type="button">Explore the local demo</button><p class="info">Credentials are sent to SocialTap to sign in. This client never saves your password.</p></form></section><section id="chat" class="chat hidden"><div class="banner hidden" id="demobanner">LOCAL DEMO · Sample messages only. Nothing is sent to SocialTap.</div><p class="notice" id="notice" role="alert"></p><div class="messages" id="messages" aria-live="polite"></div><form class="composer" id="composer"><textarea id="text" maxlength="500" placeholder="Write a message…" aria-label="Message"></textarea><footer><span class="info" id="count">0 / 500 · Enter to send</span><button class="btn primary" id="send">Send message ↑</button></footer></form></section></main></div><dialog id="newdialog"><h2>New conversation</h2><p class="muted">Enter exact usernames, separated by commas.</p><form id="createform"><label for="people">Usernames</label><input id="people" required placeholder="Taylor, Jordan"><label for="groupname">Group name (required for groups)</label><input id="groupname"><p class="error" id="createerror" role="alert"></p><div class="actions"><button type="button" class="btn" id="cancelcreate">Cancel</button><button class="btn primary" id="create">Create chat</button></div></form></dialog><dialog id="settingsdialog"><h2>Chat settings</h2><label><input type="checkbox" id="globaltoggle" style="width:auto"> Enable Global Chat</label><p class="error" id="settingerror"></p><div class="actions"><button class="btn" id="closesettings">Close</button><button class="btn primary" id="savesettings">Save</button></div></dialog><script>
const $=id=>document.getElementById(id);
const identityKey='socialtap.identity.v1';
let user=null,demo=false,active=0,chats=[],messages=[],globalEnabled=true,generation=0,authVersion=0,lastInput=Date.now(),lastSent=0,busy=false,syncBusy=false;
const errors={messages:'',sync:'',action:''};
const demoMessages={0:[{username:'Noa',content:'Welcome to the blue & white corner of SocialTap! 👋',timestamp:'10:24'},{username:'Ari',content:'A place for good conversations and new connections.',timestamp:'10:25'},{username:'You',content:'Shalom! Great to be here 🇮🇱',timestamp:'10:26'}],100:[{username:'Noa',content:'This is a sample group. Try sending a local message!',timestamp:'10:30'}]};
function rememberIdentity(value){try{if(value)localStorage.setItem(identityKey,JSON.stringify({id:value.id,username:value.username}));else localStorage.removeItem(identityKey);}catch{}}
function validIdentity(value){return value&&typeof value.username==='string'&&value.username.trim()&&Number.isSafeInteger(Number(value.id))&&Number(value.id)>0;}
function paintStatus(){
 $('notice').textContent=errors.action||errors.sync||errors.messages;
 if(user)$('status').textContent=demo?'Local demo · not connected':errors.sync||errors.messages?'Connection needs attention':'Live SocialTap · messages sync every 4 seconds';
}
function resetToLogin(reason='',forget=true){
 authVersion++;generation++;oauth=null;user=null;demo=false;active=0;chats=[];messages=[];globalEnabled=true;
 window.socialtapDesktop?.setOAuthStatus?.({connected:false});
 if(forget)rememberIdentity(null);
 errors.messages=errors.sync=errors.action='';
 $('welcome').classList.remove('hidden');$('chat').classList.add('hidden');$('demobanner').classList.add('hidden');$('shell').classList.remove('showrooms');
 for(const id of ['logout','settings','refresh','official'])$(id).classList.add('hidden');
 $('newchat').disabled=true;$('text').disabled=true;$('send').disabled=true;$('text').value='';$('password').value='';
 $('identity').textContent='Welcome to SocialTap';$('identityhint').textContent='Sign in to join the conversation.';
 $('title').textContent='A little closer, together.';$('status').textContent='Your SocialTap chat client';$('loginerror').textContent=reason;
 $('messages').replaceChildren();$('count').textContent='0 / 500 · Enter to send';
 for(const id of ['newdialog','settingsdialog'])if($(id).open)$(id).close();
 renderRooms();paintStatus();
}
async function api(path,body,form=false){
 const version=authVersion,usingOAuth=!!oauth;
 if(usingOAuth&&Date.now()>=oauth.expires-30000)await refreshAccess();
 const request=()=>fetch('/bridge'+path,{method:body===undefined?'GET':'POST',headers:{...(body===undefined?{}:{'Content-Type':form?'application/x-www-form-urlencoded':'application/json'}),...(usingOAuth&&oauth?{Authorization:'Bearer '+oauth.access}:{})},body:body===undefined?undefined:form?new URLSearchParams(body):JSON.stringify(body),signal:AbortSignal.timeout(25000)});
 if(version!==authVersion)throw Error('Connection changed.');
 const usedToken=oauth?.access;let r=await request();
 if(r.status===401&&usingOAuth&&oauth&&version===authVersion){if(oauth.access===usedToken)await refreshAccess();if(version!==authVersion)throw Error('Connection ended.');r=await request();}
 let d;try{d=await r.json();}catch{throw Error('SocialTap returned an unexpected response. Please try again.');}
 if(!r.ok||d.error||d.success===false){const e=Error(d.error||'Request failed ('+r.status+')');e.status=r.status;if(r.status===401&&user&&!demo&&version===authVersion)resetToLogin('Your SocialTap session has expired. Please sign in again.');throw e;}return d;
}
function el(tag,cls,text){const e=document.createElement(tag);e.className=cls;e.textContent=text;return e;}
function messageIsMine(message){
 const self=Number(user?.id),sender=Number(message.sender_user_id);
 if(Number.isSafeInteger(self)&&self>0&&Number.isSafeInteger(sender)&&sender>0)return self===sender;
 const name=String(user?.username||'').trim().toLowerCase();
 if(!name||name==='socialtap account')return false;
 return [message.profile_username,message.username].some(value=>typeof value==='string'&&value.trim().toLowerCase()===name);
}
function learnOwnIdentity(identity){
 if(!user||!identity)return;
 const id=Number(identity.sender_user_id??identity.user_id??identity.id);
 if(!Number.isSafeInteger(id)||id<=0)return;
 const name=identity.profile_username||identity.username;
 const changed=Number(user.id)!==id||(typeof name==='string'&&name!==user.username);
 user.id=id;if(typeof name==='string'&&name.trim())user.username=name;
 if(changed){$('identity').textContent=user.username;window.socialtapIdentityChanged?.();}
}
function roomTitle(){return active===0?'Global Chat':chats.find(c=>c.id===active)?.name||'Conversations';}
function renderRooms(){
 $('rooms').replaceChildren();
 for(const c of [...(globalEnabled?[{id:0,name:'Global Chat'}]:[]),...chats]){
  const b=el('button','room'+(c.id===active?' active':''),'');b.disabled=!user;
  const t=el('span','','');t.append(el('strong','',c.name||'Private conversation'),el('small','',c.id===0?'Everyone, in one place':c.is_private?'Private conversation':'Group conversation'));
  b.append(el('span','avatar',c.id===0?'#':(c.name||'C')[0]),t);b.onclick=()=>select(c.id);$('rooms').append(b);
 }
}
function renderMessages(){
 const box=$('messages'),near=box.scrollHeight-box.scrollTop-box.clientHeight<100;box.replaceChildren();
 if(!messages.length)box.append(el('div','empty',active===null?'Select or create a conversation.':'No messages yet. Start the conversation.'));
 for(const m of messages){
  const row=el('div','message'+(messageIsMine(m)?' me':''),'');const wrap=el('div','','');
  wrap.append(el('div','meta',(m.username||'Unknown')+' · '+(m.timestamp||'')+((m.badges||[]).length?' · '+m.badges.join(', '):'')));
  const bubble=el('div','bubble',m.content);bubble.dir='auto';wrap.append(bubble);row.append(el('div','avatar',(m.username||'?')[0]),wrap);box.append(row);
 }
 if(near)box.scrollTop=box.scrollHeight;
}
async function select(id){
 if(!user)return;active=id;generation++;messages=[];errors.messages=errors.action='';
 $('shell').classList.remove('showrooms');$('title').textContent=roomTitle();$('text').disabled=id===null;$('send').disabled=id===null||!!(oauth&&!oauth.scope.split(' ').includes('chat.send'));
 renderRooms();renderMessages();paintStatus();await load();$('messages').scrollTop=$('messages').scrollHeight;
}
async function load(){
 if(!user||active===null)return;const g=generation;
 if(demo){messages=demoMessages[active]||[];renderMessages();return;}
 try{
  const d=await api('/messages?chat_id='+encodeURIComponent(active));if(g!==generation)return;
  if(!Array.isArray(d))throw Error('Unexpected message format');
  if(JSON.stringify(messages)!==JSON.stringify(d)){messages=d;renderMessages();}
  errors.messages='';paintStatus();
 }catch(e){if(g!==generation)return;errors.messages=e.message;paintStatus();}
}
async function getChatState(){
 const [c,s]=await Promise.all([api('/api/chats'),oauth?Promise.resolve({enable_global_chat:true}):api('/api/settings')]);
 const list=Array.isArray(c)?c:c.chats;
 if(!Array.isArray(list)||typeof s.enable_global_chat!=='boolean')throw Error('SocialTap returned incomplete chat settings. Please retry.');
 return {chats:list.map(c=>({...c,id:Number(c.id)})),globalEnabled:s.enable_global_chat};
}
async function syncState(){
 if(!user||demo||syncBusy)return;const version=authVersion;syncBusy=true;
 try{
  const state=await getChatState();if(version!==authVersion)return;
  chats=state.chats;globalEnabled=state.globalEnabled;errors.sync='';
  const valid=active===0?globalEnabled:active!==null&&chats.some(c=>c.id===active);
  if(!valid)await select(globalEnabled?0:chats[0]?.id??null);
  else{renderRooms();$('title').textContent=roomTitle();}
  paintStatus();
 }catch(e){if(version!==authVersion)return;errors.sync='Could not sync conversations: '+e.message;paintStatus();}
 finally{syncBusy=false;}
}
async function start(){
 const version=authVersion;$('status').textContent=demo?'Local demo · not connected':'Connecting to your SocialTap account…';
 if(!demo){const state=await getChatState();if(version!==authVersion)return;chats=state.chats;globalEnabled=state.globalEnabled;if(!oauth)rememberIdentity(user);}
 if(version!==authVersion||!user)return;
 $('welcome').classList.add('hidden');$('chat').classList.remove('hidden');$('demobanner').classList.toggle('hidden',!demo);
 $('identity').textContent=user.username;$('identityhint').textContent=demo?'Exploring the local demo':oauth?'Secure connection · reconnect after reload':'Connected to the normal SocialTap service';
 for(const id of ['logout','settings','refresh'])$(id).classList.remove('hidden');
 $('newchat').disabled=!!oauth;$('newchat').title=oauth?'Manage conversations on the normal SocialTap website.':'';$('settings').classList.toggle('hidden',!!oauth);$('official').classList.toggle('hidden',!oauth);$('logout').textContent=oauth?'Disconnect':'Sign out';errors.messages=errors.sync=errors.action='';
 await select(globalEnabled?0:chats[0]?.id??null);paintStatus();
}
$('login').onsubmit=async e=>{
 e.preventDefault();$('signin').disabled=true;$('demo').disabled=true;$('loginerror').textContent='';const version=++authVersion;
 try{
  const name=$('username').value.trim();if(!name)throw Error('Enter your username or email.');
  const d=await api('/api/login',{email:name,password:$('password').value});
  if(version!==authVersion)return;
  const identity={username:d.username,id:d.userId};if(d.success!==true||!validIdentity(identity))throw Error('SocialTap returned an incomplete sign-in response.');
  oauth=null;user=identity;demo=false;$('password').value='';await start();
 }catch(e){if(version===authVersion)resetToLogin(e.message,e.status===401);}
 finally{$('signin').disabled=false;$('demo').disabled=false;}
};
$('demo').onclick=()=>{authVersion++;oauth=null;demo=true;user={username:'You'};globalEnabled=true;chats=[{id:100,name:'Weekend plans',is_private:false}];start();};
$('composer').onsubmit=async e=>{
 e.preventDefault();const text=$('text').value.trim(),id=active,g=generation;if(!user||!text||id===null||oauth&&!oauth.scope.split(' ').includes('chat.send'))return;$('send').disabled=true;
 try{
  if(!demo&&Date.now()-lastSent<2100)throw Error('Please wait two seconds between messages.');
  if(demo)(demoMessages[id]??=[]).push({username:'You',content:text,timestamp:new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})});
  else{const result=await api('/send',{message:text,chat_id:id},true);if(g===generation&&result.message?.sender_user_id)learnOwnIdentity(result.message);lastSent=Date.now();}
  if(g===generation){errors.action='';$('text').value='';$('text').dispatchEvent(new Event('input'));await load();$('messages').scrollTop=$('messages').scrollHeight;paintStatus();}
 }catch(e){if(g===generation){errors.action=e.message;paintStatus();}}
 finally{$('send').disabled=!user||active===null||!!(oauth&&!oauth.scope.split(' ').includes('chat.send'));}
};
$('text').oninput=()=>$('count').textContent=$('text').value.length+' / 500 · Enter to send';
$('text').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();if(!$('send').disabled)$('composer').requestSubmit();}};
$('newchat').onclick=()=>{$('createerror').textContent='';$('newdialog').showModal();};$('cancelcreate').onclick=()=>$('newdialog').close();
$('createform').onsubmit=async e=>{
 e.preventDefault();if(!user)return;const version=authVersion;$('create').disabled=true;$('createerror').textContent='';
 try{
  const names=[...new Set($('people').value.split(',').map(x=>x.trim()).filter(Boolean))],name=$('groupname').value.trim();
  if(!names.length)throw Error('Enter a username.');if(names.length>1&&!name)throw Error('Give your group a name.');let c;
  if(demo){c={id:Date.now(),name:name||names[0],is_private:names.length===1};demoMessages[c.id]=[];}
  else{const people=await Promise.all(names.map(n=>api('/api/user/lookupuseridbyusername?username='+encodeURIComponent(n))));c=(await api('/api/chats/create',{user_ids:people.map(p=>p.userId),name})).chat;}
  if(version!==authVersion)return;if(!c||!Number.isSafeInteger(Number(c.id)))throw Error('SocialTap returned an incomplete conversation.');c.id=Number(c.id);
  chats=chats.filter(x=>x.id!==c.id).concat(c);$('newdialog').close();$('createform').reset();await select(c.id);
 }catch(e){if(version===authVersion)$('createerror').textContent=e.message;}
 finally{$('create').disabled=false;}
};
$('settings').onclick=()=>{$('globaltoggle').checked=globalEnabled;$('settingerror').textContent='';$('settingsdialog').showModal();};
$('closesettings').onclick=()=>$('settingsdialog').close();
$('savesettings').onclick=async()=>{
 if(!user)return;const version=authVersion;$('savesettings').disabled=true;
 try{
  const value=$('globaltoggle').checked;if(!demo)await api('/settings/toggle-global-chat',{enable_global_chat:value});if(version!==authVersion)return;
  globalEnabled=value;renderRooms();if(!value&&active===0)await select(chats[0]?.id??null);if(value&&active===null)await select(0);$('settingsdialog').close();
 }catch(e){if(version===authVersion)$('settingerror').textContent=e.message;}
 finally{$('savesettings').disabled=false;}
};
$('logout').onclick=async()=>{const version=authVersion;try{if(oauth){if(refreshPromise)await refreshPromise;const token=oauth?.refresh;if(token)await authRequest('/auth/revoke',{token});}else if(!demo)await api('/api/logout',{});if(version===authVersion)resetToLogin();}catch(e){if(version===authVersion){errors.action=e.message;paintStatus();}}};
$('refresh').onclick=async()=>{await syncState();await load();};$('menu').onclick=()=>$('shell').classList.toggle('showrooms');
setInterval(async()=>{if(!user||demo||busy||document.hidden)return;busy=true;try{await load();}finally{busy=false;}},4000);
setInterval(()=>{if(!document.hidden)syncState();},15000);
function resume(){if(!document.hidden&&user&&!demo){syncState();load();}}
window.addEventListener('focus',resume);document.addEventListener('visibilitychange',resume);
async function heartbeat(){if(user&&!demo&&!oauth)try{await api('/api/user/presence',{idle_seconds:Math.min(2147483647,Math.floor((Date.now()-lastInput)/1000))});}catch{}}
for(const event of ['pointermove','pointerdown','keydown','scroll','touchstart'])window.addEventListener(event,()=>{const resumed=Date.now()-lastInput>300000;lastInput=Date.now();if(resumed)heartbeat();},{passive:true});
setInterval(heartbeat,60000);
async function restoreSession(){
 let identity;try{identity=JSON.parse(localStorage.getItem(identityKey));}catch{}if(!validIdentity(identity))return;
 const version=++authVersion;$('signin').disabled=true;$('demo').disabled=true;$('status').textContent='Checking your SocialTap session…';
 try{
  const presence=await api('/api/user/presence');if(version!==authVersion)return;
  if(String(presence.user_id)!==String(identity.id)){resetToLogin('Please sign in to confirm your SocialTap account.');return;}
  user={id:Number(identity.id),username:identity.username};demo=false;await start();
 }catch(e){if(version===authVersion)resetToLogin(e.status===401?'Your SocialTap session has expired. Please sign in again.':'Could not restore your session: '+e.message,e.status===401);}
 finally{$('signin').disabled=false;$('demo').disabled=false;}
}
let oauth=null,refreshPromise=null;
const pendingKey='socialtap.oauth.pending.v1';
function b64url(bytes){return btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function randomValue(){return b64url(crypto.getRandomValues(new Uint8Array(32)));}
async function authRequest(path,body){
 const r=await fetch(path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/x-www-form-urlencoded'}:{},body:body?new URLSearchParams(body):undefined,signal:AbortSignal.timeout(25000)});
 const d=await r.json();if(!r.ok||d.error){const e=Error(d.error_description||d.error||'Could not connect to SocialTap.');e.status=r.status;throw e;}return d;
}
function tokenPair(d){
 if(typeof d.access_token!=='string'||!d.access_token||typeof d.refresh_token!=='string'||!d.refresh_token||String(d.token_type).toLowerCase()!=='bearer'||!Number.isFinite(Number(d.expires_in))||Number(d.expires_in)<=0)throw Error('SocialTap returned an incomplete connection. Please reconnect.');
 if(!String(d.scope||'').split(' ').includes('chat.read'))throw Error('Reading chats was not approved. Please reconnect.');
 return {access:d.access_token,refresh:d.refresh_token,expires:Date.now()+Number(d.expires_in)*1000,scope:String(d.scope)};
}
async function refreshAccess(){
 if(refreshPromise)return refreshPromise;
 if(!oauth)throw Error('Please reconnect to SocialTap.');
 const version=authVersion,old=oauth;
 const task=(async()=>{try{const d=await authRequest('/auth/token',{grant_type:'refresh_token',refresh_token:old.refresh});const next=tokenPair(d);if(version!==authVersion||oauth!==old)throw Error('Connection changed.');oauth=next;return next.access;}catch(e){if(version===authVersion)resetToLogin('Your connection ended. Please reconnect to SocialTap.');throw e;}})();
 refreshPromise=task;try{return await task;}finally{if(refreshPromise===task)refreshPromise=null;}
}
async function connectSocialTap(){
 $('google-signin').disabled=true;$('loginerror').textContent='';
 try{
  const c=await authRequest('/auth/config');
  if(c.issuer!=='https://www.socialtap.social'||new URL(c.authorization_endpoint).origin!==c.issuer||c.redirect_uri!==location.origin+'/oauth/callback')throw Error('Invalid SocialTap sign-in configuration.');
  const verifier=randomValue(),state=randomValue(),challenge=b64url(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier))));
  sessionStorage.setItem(pendingKey,JSON.stringify({verifier,state,issuer:c.issuer,client_id:c.client_id,redirect_uri:c.redirect_uri,created:Date.now()}));
  const url=new URL(c.authorization_endpoint);url.search=new URLSearchParams({response_type:'code',client_id:c.client_id,redirect_uri:c.redirect_uri,scope:c.scope,state,code_challenge:challenge,code_challenge_method:'S256'}).toString();
  if(window.socialtapDesktop){
   $('status').textContent='Complete sign-in in your browser. This window will reconnect automatically.';
   await window.socialtapDesktop.authorize(url.href);
   $('google-signin').disabled=false;
  }else location.assign(url.href);
 }catch(e){sessionStorage.removeItem(pendingKey);$('loginerror').textContent=e.message;$('google-signin').disabled=false;}
}
async function finishOAuth(search=location.search){
 const query=new URLSearchParams(search);history.replaceState(null,'','/');
 let pending;try{pending=JSON.parse(sessionStorage.getItem(pendingKey));}catch{}sessionStorage.removeItem(pendingKey);
 $('google-signin').disabled=true;$('signin').disabled=true;$('demo').disabled=true;$('status').textContent='Completing your SocialTap connection…';
 try{
  if(!pending||!query.get('state')||query.getAll('state').length!==1||query.get('state')!==pending.state||Date.now()-pending.created>600000||Date.now()<pending.created)throw Error('This sign-in link expired or belongs to another tab. Please connect again.');
  if(query.has('error'))throw Error(query.get('error')==='access_denied'?'Connection cancelled. You can try again whenever you are ready.':'SocialTap could not complete sign-in.');
  if(query.getAll('iss').length!==1||query.get('iss')!=='https://www.socialtap.social'||query.get('iss')!==pending.issuer||query.getAll('code').length!==1||!query.get('code'))throw Error('SocialTap sign-in could not be verified. Please connect again.');
  const config=await authRequest('/auth/config');
  if(config.client_id!==pending.client_id||config.redirect_uri!==pending.redirect_uri||config.issuer!==pending.issuer)throw Error('Sign-in configuration changed. Please connect again.');
  const d=await authRequest('/auth/token',{grant_type:'authorization_code',code:query.get('code'),code_verifier:pending.verifier,redirect_uri:pending.redirect_uri});
  oauth=tokenPair(d);authVersion++;demo=false;rememberIdentity(null);user={username:d.username||'SocialTap account',id:d.userId||null};
  window.socialtapDesktop?.setOAuthStatus?.({connected:true});
  await start();
 }catch(e){if(oauth){errors.sync=e.message;$('welcome').classList.add('hidden');$('chat').classList.remove('hidden');$('logout').classList.remove('hidden');$('refresh').classList.remove('hidden');$('official').classList.remove('hidden');paintStatus();}else resetToLogin(e.message);}
 finally{$('google-signin').disabled=false;$('signin').disabled=false;$('demo').disabled=false;}
}
$('google-signin').onclick=connectSocialTap;
window.socialtapDesktop?.onOAuthCallback?.(async search=>{
 if(typeof search!=='string'||!search.startsWith('?')||search.length>16384)return;
 let pending;try{pending=JSON.parse(sessionStorage.getItem(pendingKey));}catch{return;}
 const query=new URLSearchParams(search);
 if(!pending||query.getAll('state').length!==1||query.get('state')!==pending.state)return;
 await finishOAuth(search);
});

renderRooms();if(location.pathname==='/oauth/callback')finishOAuth();else restoreSession();
</script></body></html>`;
