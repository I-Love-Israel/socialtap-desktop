import test from 'node:test';
import assert from 'node:assert/strict';
import {attachmentRequest,MAX_FILE} from '../desktop/attachments-proxy.mjs';
import {safeFilename,canOpenFile} from '../desktop/file-policy.mjs';
const base='http://127.0.0.1:4317';
const upload=(bytes=new Uint8Array([0,255,13,10,128]))=>{const form=new FormData();form.set('file',new Blob([bytes]),'example.bin');form.set('chat_id','21');form.set('message','שלום');return form;};
test('OAuth uploads preserve binary bytes and never forward local cookies or CSRF',async()=>{
 const req=new Request(base+'/bridge/attachments',{method:'POST',headers:{Origin:base,Authorization:'Bearer test-token',Cookie:'st_session=private; unrelated=other'},body:upload()});
 let count=0;
 const result=await attachmentRequest(req,async(url,options)=>{count++;assert.equal(url,'https://www.socialtap.social/attachments');assert.equal(options.headers.get('Authorization'),'Bearer test-token');assert.equal(options.headers.has('Cookie'),false);assert.equal(options.body.has('csrf_token'),false);assert.equal(options.body.get('message'),'שלום');assert.deepEqual(new Uint8Array(await options.body.get('file').arrayBuffer()),new Uint8Array([0,255,13,10,128]));return Response.json({id:1},{headers:{'Set-Cookie':'session=not-forwarded'}});});
 assert.equal(result.status,200);assert.equal(count,1);assert.equal(result.headers.has('Set-Cookie'),false);
});
test('session uploads fetch CSRF and use a rotated session without disclosing friends',async()=>{
 let count=0;const response=await attachmentRequest(new Request(base+'/bridge/attachments',{method:'POST',headers:{Origin:base,Cookie:'st_session=old; hosting=secret'},body:upload()}),async(url,options)=>{count++;if(count===1){assert.equal(url,'https://www.socialtap.social/api/friends');assert.equal(options.headers.get('Cookie'),'session=old');return Response.json({csrf_token:'csrf',friends:['private']},{headers:{'Set-Cookie':'session=new; Path=/'}});}assert.equal(options.headers.get('Cookie'),'session=new');assert.equal(options.body.get('csrf_token'),'csrf');return Response.json({id:1});});
 assert.equal(response.status,200);assert.equal(count,2);assert.match(response.headers.get('Set-Cookie'),/st_session=new/);assert.deepEqual(await response.json(),{id:1});
});
test('cross-origin, oversized and unsafe attachment requests never contact upstream',async()=>{
 let calls=0;const noFetch=async()=>{calls++;throw Error('unexpected');};
 const foreign=await attachmentRequest(new Request(base+'/bridge/attachments',{method:'POST',headers:{Origin:'https://evil.example',Authorization:'Bearer token'},body:upload()}),noFetch);assert.equal(foreign.status,403);
 const huge=await attachmentRequest(new Request(base+'/bridge/attachments',{method:'POST',headers:{Origin:base,Authorization:'Bearer token'},body:upload(new Uint8Array(MAX_FILE+1))}),noFetch);assert.equal(huge.status,413);
 for(const path of ['/attachments/file?id=other','/attachments/a%2Fb','/attachments/../account']){const r=await attachmentRequest(new Request(base+'/bridge'+path,{headers:{Authorization:'Bearer token'}}),noFetch);assert.ok(r.status>=400);}
 assert.equal(calls,0);
});
test('downloads return exact binary bytes, private headers, and no active HTML',async()=>{
 const response=await attachmentRequest(new Request(base+'/bridge/attachments/id_123',{headers:{Authorization:'Bearer token'}}),async(url,options)=>{assert.equal(url,'https://www.socialtap.social/attachments/id_123');assert.equal(options.redirect,'manual');return new Response(new Uint8Array([0,255,64]),{headers:{'Content-Type':'text/html'}});});
 assert.deepEqual(new Uint8Array(await response.arrayBuffer()),new Uint8Array([0,255,64]));assert.equal(response.headers.get('Content-Type'),'application/octet-stream');assert.equal(response.headers.get('Cache-Control'),'no-store');assert.match(response.headers.get('Content-Security-Policy'),/sandbox/);
});
test('upload uncertainty is reported without retry, and expired downloads stay unavailable',async()=>{
 let calls=0;const response=await attachmentRequest(new Request(base+'/bridge/attachments',{method:'POST',headers:{Origin:base,Authorization:'Bearer token'},body:upload()}),async()=>{calls++;throw Error('network');});
 assert.equal(calls,1);assert.match((await response.json()).error,/not confirmed/);
 const expired=await attachmentRequest(new Request(base+'/bridge/attachments/id',{headers:{Authorization:'Bearer token'}}),async()=>new Response('',{status:410}));assert.equal(expired.status,410);
});
test('all filenames can be saved, while executable downloads are never automatically opened',()=>{
 assert.equal(safeFilename('../../CON.exe'),'.._.._CON.exe');assert.equal(safeFilename('CON'),'attachment_CON');
 for(const name of ['report.pdf','photo.webp','notes.docx','audio.mp3'])assert.equal(canOpenFile(name),true);
 for(const name of ['app.exe','script.js','installer.msi','shortcut.lnk','macro.docm','page.html','command.ps1'])assert.equal(canOpenFile(name),false);
});
