import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
function harness(fetcher=async()=>Response.json({id:1})){
 const elements=new Map(),requests=[];
 class Element{
  constructor(tag='div'){this.tagName=tag.toUpperCase();this.children=[];this.value='';this.classList={add(){},remove(){}};}
  append(...nodes){this.children.push(...nodes);}prepend(...nodes){this.children.unshift(...nodes);}replaceChildren(...nodes){this.children=nodes;}setAttribute(){}addEventListener(){}dispatchEvent(){}remove(){}click(){}showModal(){}close(){}
  querySelectorAll(selector){const cls=selector.slice(1);return this.children.flatMap(n=>n instanceof Element?[...(String(n.className||'').split(' ').includes(cls)?[n]:[]),...n.querySelectorAll(selector)]:[]);}
  querySelector(selector){return this.querySelectorAll(selector)[0];}
 }
 const get=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
 const render=()=>{get('messages').replaceChildren();for(const message of context.messages){const row=new Element();row.className='message';const bubble=new Element();bubble.className='bubble';row.append(bubble);get('messages').append(row);}};
 get('composer').onsubmit=async()=>{};
 const context=vm.createContext({window:{socialtapDesktop:{saveFile:async()=>({saved:true})}},document:{createElement:tag=>new Element(tag),addEventListener(){},head:new Element(),body:new Element(),querySelectorAll:()=>[]},$:get,renderMessages:render,select:async id=>{context.active=id;},resetToLogin(){context.user=null;context.oauth=null;context.authVersion++;},user:{username:'Test'},demo:false,active:21,authVersion:1,oauth:{access:'access',refresh:'refresh',expires:Date.now()+900000,scope:'chat.read chat.send'},errors:{},messages:[],lastSent:0,paintStatus(){},load:async()=>{},refreshAccess:async()=>{},fetch:async(...args)=>{requests.push(args);return fetcher(...args);},setTimeout,Date,Number,Map,Set,URL,Blob,FormData,Uint8Array,TextDecoder,AbortSignal,Event});
 vm.runInContext(readFileSync(new URL('../desktop/attachments.js',import.meta.url),'utf8'),context);
 const input=get('composer').children[0].children[1];
 return {context,requests,get,choose:files=>{input.files=files;input.onchange();},submit:()=>get('composer').onsubmit({preventDefault(){}})};
}
test('selecting a file never uploads it; submitting sends one binary file and caption to the selected chat',async()=>{
 const h=harness();h.choose([new File(['bytes'],'notes.txt')]);assert.equal(h.requests.length,0);
 h.get('text').value='caption';await h.submit();assert.equal(h.requests.length,1);
 const [url,options]=h.requests[0];assert.equal(url,'/bridge/attachments');assert.equal(options.body.get('chat_id'),'21');assert.equal(options.body.get('message'),'caption');assert.equal(await options.body.get('file').text(),'bytes');assert.equal(h.get('text').value,'');
});
test('an uncertain upload is not retried and keeps its draft for the user to review',async()=>{
 const h=harness(async()=>{throw Error('timeout');});h.choose([new File(['bytes'],'notes.txt')]);h.get('text').value='keep me';await h.submit();
 assert.equal(h.requests.length,1);assert.match(h.context.errors.action,/not confirmed/);assert.equal(h.get('text').value,'keep me');
});
test('file drafts stay in their original conversation and unavailable attachments have no open controls',async()=>{
 const h=harness();h.choose([new File(['bytes'],'notes.txt')]);await h.context.select(22);await h.submit();assert.equal(h.requests.length,0);
 h.context.messages=[{attachment:{id:'expired',filename:'expired.pdf',size:10,expired:true}}];h.context.renderMessages();
 const card=h.get('messages').querySelector('.attachment-card');assert.equal(card.children.filter(n=>n.tagName==='BUTTON').length,0);assert.match(card.children[1].textContent,/expired/);
});
