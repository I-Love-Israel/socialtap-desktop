import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker/index.js';

const site = 'https://client.example';
function request(path, options = {}) {
  const { base = site, ...init } = options;
  return new Request(base + '/bridge' + path, init);
}
async function withUpstream(handler, run) {
  const original = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (url, options) => {
    calls.push({ url: String(url), options });
    return handler(url, options);
  };
  try { await run(calls); } finally { globalThis.fetch = original; }
}
const json = (body = { success: true }, options) => Response.json(body, options);

test('proxy rejects unlisted paths and methods without contacting upstream', async () => {
  await withUpstream(() => { throw Error('Unexpected upstream request'); }, async calls => {
    for (const [path, method] of [['/api/chats/delete/42', 'DELETE'], ['/api/login', 'GET'], ['/send', 'GET'], ['//attacker.example', 'GET']]) {
      const response = await worker.fetch(request(path, { method }));
      assert.equal(response.status, 405);
    }
    assert.equal(calls.length, 0);
  });
});

test('POST requires a matching browser origin', async () => {
  await withUpstream(() => json(), async calls => {
    for (const headers of [{}, { Origin: 'https://attacker.example' }]) {
      const response = await worker.fetch(request('/api/logout', { method: 'POST', headers }));
      assert.equal(response.status, 403);
    }
    assert.equal(calls.length, 0);
  });
});

test('only the SocialTap session is forwarded, with the exact upstream query', async () => {
  await withUpstream(() => json([]), async calls => {
    const response = await worker.fetch(request('/messages?chat_id=42&last_id=10', {
      headers: { Cookie: 'other_secret=never-forward; st_session=opaque.test.signature; analytics=ignored' },
    }));
    assert.equal(response.status, 200);
    assert.equal(calls.length, 1);
    assert.equal(calls[0].url, 'https://www.socialtap.social/messages?chat_id=42&last_id=10');
    assert.equal(calls[0].options.headers.get('cookie'), 'session=opaque.test.signature');
    assert.equal(calls[0].options.redirect, 'manual');
    assert.equal(response.headers.get('cache-control'), 'no-store');
  });
});

test('hosted session cookies are scoped to this client and remain HttpOnly and Secure', async () => {
  await withUpstream(() => json({}, { headers: {
    'Set-Cookie': 'session=opaque; Domain=.socialtap.social; Path=/; Secure; HttpOnly; SameSite=Lax',
  } }), async () => {
    const response = await worker.fetch(request('/api/login', { method: 'POST', headers: { Origin: site } }));
    const cookies = response.headers.getSetCookie();
    assert.equal(cookies.length, 1);
    assert.match(cookies[0], /^st_session=opaque;/);
    assert.doesNotMatch(cookies[0], /Domain=/i);
    assert.match(cookies[0], /;\s*Path=\//i);
    assert.match(cookies[0], /;\s*HttpOnly(?:;|$)/i);
    assert.match(cookies[0], /;\s*Secure(?:;|$)/i);
    assert.match(cookies[0], /;\s*SameSite=Strict(?:;|$)/i);
  });
});

test('loopback preview session cookies can work over HTTP', async () => {
  await withUpstream(() => json({}, { headers: { 'Set-Cookie': 'session=opaque; Path=/; Secure; HttpOnly' } }), async () => {
    const base = 'http://127.0.0.1:4317';
    const response = await worker.fetch(request('/api/login', { base, method: 'POST', headers: { Origin: base } }));
    const cookie = response.headers.get('set-cookie');
    assert.match(cookie, /^st_session=opaque;/);
    assert.doesNotMatch(cookie, /;\s*Secure(?:;|$)/i);
    assert.match(cookie, /;\s*HttpOnly(?:;|$)/i);
  });
});

test('message sending preserves required form encoding and Unicode content', async () => {
  const body = new URLSearchParams({ message: 'שלום & hello', chat_id: '42' }).toString();
  await withUpstream(() => json({ success: true, message: { id: 1 } }), async calls => {
    const response = await worker.fetch(request('/send', {
      method: 'POST', headers: { Origin: site, 'Content-Type': 'application/x-www-form-urlencoded' }, body,
    }));
    assert.equal(response.status, 200);
    assert.equal(calls[0].options.method, 'POST');
    assert.equal(calls[0].options.body, body);
    assert.equal(calls[0].options.headers.get('content-type'), 'application/x-www-form-urlencoded');
  });
});

test('presence supports both authenticated session reads and heartbeats', async () => {
  await withUpstream(() => json({ user_id: 42 }), async calls => {
    const read = await worker.fetch(request('/api/user/presence'));
    const write = await worker.fetch(request('/api/user/presence', {
      method: 'POST', headers: { Origin: site, 'Content-Type': 'application/json' }, body: '{"idle_seconds":305}',
    }));
    assert.equal(read.status, 200);
    assert.equal(write.status, 200);
    assert.equal(calls.length, 2);
  });
});

test('login redirects become a session-expired response without following redirects', async () => {
  await withUpstream(() => new Response(null, { status: 302, headers: { Location: '/login' } }), async () => {
    const response = await worker.fetch(request('/messages'));
    assert.equal(response.status, 401);
    assert.match((await response.json()).error, /sign in/i);
  });
});

test('upstream HTML and network error internals are not exposed to the browser', async () => {
  for (const [handler, expectedStatus] of [
    [() => new Response('<html>private server traceback</html>', { status: 500, headers: { 'Content-Type': 'text/html' } }), 500],
    [() => { throw Error('private upstream connection details'); }, 502],
  ]) {
    await withUpstream(handler, async () => {
      const response = await worker.fetch(request('/messages'));
      assert.equal(response.status, expectedStatus);
      assert.match(response.headers.get('content-type'), /application\/json/);
      const body = await response.text();
      assert.doesNotMatch(body, /private|traceback|<html>/);
      assert.ok(JSON.parse(body).error);
    });
  }
});
