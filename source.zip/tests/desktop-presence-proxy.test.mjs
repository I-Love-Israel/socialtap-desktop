import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../desktop/worker.mjs';
test('desktop allows only OAuth presence writes, preserving account and credential isolation',async()=>{
 const original=globalThis.fetch,calls=[];
 globalThis.fetch=async(url,options)=>{calls.push({url,options});return Response.json({presence:'online'});};
 try{
  const headers={Origin:'http://127.0.0.1:4317',Authorization:'Bearer test-token',Cookie:'st_session=other','Content-Type':'application/json'};
  const post=await worker.fetch(new Request('http://127.0.0.1:4317/bridge/api/user/presence',{method:'POST',headers,body:JSON.stringify({idle_seconds:17})}));
  assert.equal(post.status,200);assert.equal(calls.length,1);assert.equal(calls[0].url,'https://www.socialtap.social/api/user/presence');assert.equal(calls[0].options.headers.get('Cookie'),null);
  assert.deepEqual(JSON.parse(calls[0].options.body),{idle_seconds:17});
  const get=await worker.fetch(new Request('http://127.0.0.1:4317/bridge/api/user/presence',{headers}));assert.equal(get.status,403);assert.equal(calls.length,1);
  const config=await (await worker.fetch(new Request('http://127.0.0.1:4317/auth/config'))).json();assert.ok(config.scope.split(' ').includes('presence.write'));
 }finally{globalThis.fetch=original;}
});
