import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {createNotifier} from '../desktop/notifications.mjs';
function harness({visible=false,focused=false,enabled=true,fail=false}={}){
 const shown=[],clicked=[];
 class Notification extends EventEmitter{static isSupported(){return true;}constructor(options){super();this.options=options;shown.push(this);}show(){this.emit(fail?'failed':'show');}}
 const notify=createNotifier({Notification,getWindow:()=>({isVisible:()=>visible,isFocused:()=>focused}),enabled:()=>enabled,icon:'icon.ico',onClick:id=>clicked.push(id)});
 return {notify,shown,clicked};
}
test('hidden-window notifications reach Windows and clicking them opens the conversation',async()=>{
 const h=harness();assert.equal(await h.notify({title:'SocialTap',body:'New message',chatId:21,kind:'message'}),true);
 h.shown[0].emit('click');assert.deepEqual(h.clicked,[21]);assert.equal(h.shown[0].options.body,'New message');
});
test('simultaneous messages in different chats are not discarded by a global throttle',async()=>{
 const h=harness();await Promise.all([21,22,23].map(chatId=>h.notify({title:'SocialTap',chatId,kind:'message'})));assert.equal(h.shown.length,3);
});
test('notification preferences and focused-window suppression are respected, and native failures are reported',async()=>{
 const focused=harness({visible:true,focused:true});assert.equal(await focused.notify({title:'SocialTap',kind:'message'}),false);assert.equal(focused.shown.length,0);
 assert.equal(await focused.notify({title:'Test',kind:'test'}),true);
 assert.equal(await harness({enabled:false}).notify({title:'Disabled'}),false);
 assert.equal(await harness({fail:true}).notify({title:'Failure'}),false);
});
