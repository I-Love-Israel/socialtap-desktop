import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createHash} from 'node:crypto';

const base='http://127.0.0.1:4317';
const config={...JSON.parse(fs.readFileSync(new URL('../oauth-client.json',import.meta.url),'utf8')),redirect_uri:base+'/oauth/callback',scope:'chat.read chat.send'};
const script=fs.readFileSync(new URL('../worker/index.js',import.meta.url),'utf8').split('<script>')[1].split('</script>')[0];
function desktop({launchError=false}={}){
 const elements=new Map(),storage=new Map(),requests=[],opened=[],status=[],navigations=[];
 let callback;
 const element=()=>({classList:{add(){},remove(){},toggle(){}},append(){},replaceChildren(){},textContent:'',value:'',disabled:false,open:false});
 const fetch=async(path,options)=>{
  requests.push({path,options});
  if(path==='/auth/config')return Response.json(config);
  if(path==='/auth/token')return Response.json({access_token:'desktop-test-access',refresh_token:'desktop-test-refresh',expires_in:900,token_type:'Bearer',scope:'chat.read chat.send',username:'Account'});
  if(path==='/bridge/api/chats'||path.startsWith('/bridge/messages?'))return Response.json([]);
  throw Error('Unexpected request: '+path);
 };
 const context=vm.createContext({fetch,URL,URLSearchParams,AbortSignal,TextEncoder,Uint8Array,Date,console,crypto:globalThis.crypto,btoa,document:{hidden:false,getElementById(id){if(!elements.has(id))elements.set(id,element());return elements.get(id);},createElement:element,addEventListener(){}},window:{addEventListener(){},socialtapDesktop:{async authorize(url){opened.push(url);if(launchError)throw Error('Browser could not open.');},onOAuthCallback(fn){callback=fn;},setOAuthStatus(value){status.push(value.connected);}}},setInterval(){},location:{pathname:'/',origin:base,search:'',assign(url){navigations.push(url);}},history:{replaceState(){}},sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},localStorage:{getItem:()=>null,setItem(){throw Error('Tokens must never be persisted');},removeItem(){}}});
 vm.runInContext(script,context);
 return {context,elements,storage,requests,opened,status,navigations,receive:search=>callback(search)};
}

test('desktop sign-in opens system browser while preserving PKCE in the app',async()=>{
 const d=desktop();await vm.runInContext('connectSocialTap()',d.context);
 assert.equal(d.opened.length,1);assert.deepEqual(d.navigations,[]);
 const url=new URL(d.opened[0]),pending=JSON.parse(d.storage.get('socialtap.oauth.pending.v1'));
 assert.equal(url.origin+url.pathname,config.authorization_endpoint);
 assert.equal(url.searchParams.get('state'),pending.state);
 assert.equal(url.searchParams.get('redirect_uri'),base+'/oauth/callback');
 assert.equal(url.searchParams.get('code_challenge_method'),'S256');
 assert.equal(url.searchParams.get('code_challenge'),createHash('sha256').update(pending.verifier).digest('base64url'));
 assert.equal(d.elements.get('google-signin').disabled,false);
});

test('desktop callback uses saved PKCE once and ignores callbacks with unrelated state',async()=>{
 const d=desktop();await vm.runInContext('connectSocialTap()',d.context);
 const pending=JSON.parse(d.storage.get('socialtap.oauth.pending.v1'));
 await d.receive('?code=wrong&state=unrelated&iss='+encodeURIComponent(config.issuer));
 assert.equal(d.requests.filter(r=>r.path==='/auth/token').length,0);assert.equal(d.storage.size,1);
 const search='?'+new URLSearchParams({code:'desktop-code',state:pending.state,iss:config.issuer});
 await d.receive(search);
 const exchanges=d.requests.filter(r=>r.path==='/auth/token');assert.equal(exchanges.length,1);
 assert.equal(exchanges[0].options.body.get('code_verifier'),pending.verifier);
 assert.equal(exchanges[0].options.body.get('redirect_uri'),base+'/oauth/callback');
 assert.equal(d.storage.size,0);assert.equal(vm.runInContext('oauth.access',d.context),'desktop-test-access');
 assert.deepEqual(d.status,[true]);
 await d.receive(search);assert.equal(d.requests.filter(r=>r.path==='/auth/token').length,1);
 assert.equal(vm.runInContext('oauth.access',d.context),'desktop-test-access');
 vm.runInContext('resetToLogin()',d.context);assert.deepEqual(d.status,[true,false]);
});

test('desktop callbacks still reject an invalid issuer before exchanging a code',async()=>{
 const d=desktop();await vm.runInContext('connectSocialTap()',d.context);
 const pending=JSON.parse(d.storage.get('socialtap.oauth.pending.v1'));
 await d.receive('?'+new URLSearchParams({code:'code',state:pending.state,iss:'https://evil.example'}));
 assert.equal(d.requests.filter(r=>r.path==='/auth/token').length,0);
 assert.equal(vm.runInContext('oauth',d.context),null);assert.deepEqual(d.status,[false]);
});

test('failure to open the browser clears pending sign-in and leaves retry available',async()=>{
 const d=desktop({launchError:true});await vm.runInContext('connectSocialTap()',d.context);
 assert.equal(d.storage.size,0);assert.equal(d.elements.get('google-signin').disabled,false);
 assert.equal(d.elements.get('loginerror').textContent,'Browser could not open.');
});
