import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {CLIENT_ID,REDIRECT,ISSUER,validAuthorization,validCallback} from '../desktop/config.mjs';
const authorize=()=>new URL(ISSUER+'/api/oauth/authorize?'+new URLSearchParams({client_id:CLIENT_ID,redirect_uri:REDIRECT,response_type:'code',code_challenge_method:'S256',state:'s'.repeat(43),code_challenge:'c'.repeat(43),scope:'chat.read chat.send voice.call account.read voice.audio'}));
test('desktop authorize gate rejects alternate issuers, callbacks, duplicate parameters and undeclared scopes',()=>{
 assert.ok(validAuthorization(authorize().href));
 for(const mutate of [u=>u.hostname='www.socialtap.social.evil.example',u=>u.searchParams.set('redirect_uri','http://evil.example/'),u=>u.searchParams.append('state','extra'),u=>u.searchParams.set('scope','chat.read chat.send voice.call shop.purchase'),u=>u.searchParams.set('code_challenge_method','plain')]){const u=authorize();mutate(u);assert.equal(validAuthorization(u.href),null);}
});
test('callback gate requires current state and issuer without accepting duplicate keys',()=>{
 const pending=validAuthorization(authorize().href),q=new URLSearchParams({state:pending.state,code:'test-code',iss:ISSUER});
 assert.equal(validCallback(q.toString(),pending),true);
 assert.equal(validCallback(q.toString(),{...pending,created:Date.now()-610000}),false);
 q.append('code','duplicate');assert.equal(validCallback(q.toString(),pending),false);
});
function harness({saved=null,timeoutSend=false,scopeError=false,deferSend=false,memberChats=[]}={}){
 const elements=new Map(),requests=[],notes=[],sockets=[],timers=[],stored=[];
 let sendAcknowledgement;
 class Element{constructor(){this.children=[];this.style={};this.classList={add(){},remove(){},toggle(){}};this.parentElement={append(){}};}append(...children){this.children.push(...children);}setAttribute(){}showModal(){this.open=true;}close(){this.open=false;}}
 const element=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
 const bridge={getSettings:async()=>({notifications:true,startup:true,closeToTray:true}),updateSettings:async x=>x,getIdleSeconds:async()=>420,notify:x=>notes.push(x),onNotificationClick(){},saveSession:async x=>{stored.push(x);return true;},loadSession:async()=>saved,clearSession:async()=>{stored.push(null);},setOAuthStatus(){}};
 const io=(_url,options)=>{
  const handlers=new Map();const socket={connected:false,id:'test-socket',auth:options.auth,on(e,fn){if(!handlers.has(e))handlers.set(e,new Set());handlers.get(e).add(fn);return this;},off(e,fn){handlers.get(e)?.delete(fn);},once(e,fn){const run=(...a)=>{this.off(e,run);fn(...a);};return this.on(e,run);},connect(){this.auth(auth=>{this.usedAuth=auth;this.connected=true;for(const fn of handlers.get('connect')||[])fn();});},disconnect(){this.connected=false;for(const fn of handlers.get('disconnect')||[])fn();},removeAllListeners(){handlers.clear();},timeout(){return this;},emit(event,payload,cb){requests.push({event,payload});if(event==='message:send'&&deferSend){sendAcknowledgement=cb;return;}if(event==='message:send'&&timeoutSend)return cb(Error('timeout'));if(scopeError)return cb(null,{status:403,error:'insufficient_scope'});if(event==='notifications:get')return cb(null,{status:200,data:{since:requests.length,updates:[{chat_id:21,new_messages:1}]}});cb(null,{status:200,data:[]});}};sockets.push(socket);return socket;
 };
 const context=vm.createContext({window:{socialtapDesktop:bridge,addEventListener(){}},document:{createElement:()=>new Element(),createTextNode:x=>x,querySelector:()=>new Element(),body:new Element()},$:element,api:async(path,body)=>{requests.push({path,body});if(path==='/api/settings')return {enable_global_chat:true};return {};},start:async()=>{},resetToLogin(){context.oauth=null;context.user=null;context.authVersion++;},refreshAccess:async()=>{context.oauth={...context.oauth,access:'fresh-access',refresh:'fresh-refresh',expires:Date.now()+900000};return context.oauth.access;},getChatState:async()=>({chats:[],globalEnabled:true}),select:async()=>{},load:async()=>{},heartbeat(){},oauth:null,user:null,demo:false,authVersion:0,chats:[],active:0,globalEnabled:true,io,Date,Number,Promise,Map,Set,URLSearchParams,setTimeout,clearTimeout,setInterval:fn=>{timers.push(fn);return timers.length;},clearInterval(){},sessionStorage:{getItem:()=>null},pendingKey:'pending'});
 context.syncState=async()=>{};
 context.renderMessages=()=>{};
 context.getChatState=async()=>({chats:memberChats,globalEnabled:true});
 const workerSource=readFileSync(new URL('../worker/index.js',import.meta.url),'utf8');
 vm.runInContext(workerSource.slice(workerSource.indexOf('function messageIsMine'),workerSource.indexOf('function roomTitle')),context);
 bridge.getIdleSeconds=async()=>0;
 vm.runInContext(readFileSync(new URL('../desktop/renderer.js',import.meta.url),'utf8'),context);
 return {context,bridge,requests,notes,sockets,timers,stored,acknowledgeSend:ack=>sendAcknowledgement(null,ack),flush:()=>new Promise(resolve=>setImmediate(resolve)),login:async()=>{context.oauth={access:'access',refresh:'refresh',scope:'chat.read chat.send voice.call voice.audio',expires:Date.now()+900000};context.user={username:'Test'};context.authVersion++;await context.start();}};
}
test('desktop uses OAuth Socket.IO and never replays a message whose delivery timed out',async()=>{
 const h=harness({timeoutSend:true});await h.login();await h.flush();
 assert.equal(h.sockets[0].usedAuth.access_token,'access');
 await assert.rejects(()=>h.context.api('/send',{chat_id:21,message:'local test'},true),/not confirmed/);
 assert.equal(h.requests.filter(x=>x.event==='message:send').length,1);
 assert.equal(h.requests.filter(x=>x.path==='/send').length,0);
});
test('notifications skip existing history and notify only subsequent deltas',async()=>{
 const h=harness();await h.login();await h.flush();assert.equal(h.notes.length,0);
 h.timers[0]();await h.flush();assert.equal(h.notes.length,1);assert.match(h.notes[0].body,/new message/);
});
test('an explicit socket scope denial falls back to the authorized HTTP chat API',async()=>{
 const h=harness({scopeError:true});await h.login();await h.flush();
 await h.context.api('/messages?chat_id=21');
 await h.context.api('/send',{chat_id:21,message:'test'},true);
 assert.equal(h.requests.filter(x=>x.path==='/messages?chat_id=21').length,1);
 assert.equal(h.requests.filter(x=>x.path==='/send').length,1);
 assert.equal(h.requests.filter(x=>x.event==='message:send').length,1);
});
test('a delayed scope denial never sends the old message through a different account',async()=>{
 const h=harness({deferSend:true});await h.login();await h.flush();
 const pendingSend=h.context.api('/send',{chat_id:21,message:'original account message'},true);
 const rejected=assert.rejects(pendingSend,/insufficient_scope/);
 await h.flush();
 h.context.resetToLogin();await h.login();
 h.context.oauth={...h.context.oauth,access:'different-account-access',refresh:'different-account-refresh'};
 h.context.user={username:'Different account'};
 h.acknowledgeSend({status:403,error:'insufficient_scope'});
 await rejected;
 assert.equal(h.requests.filter(x=>x.event==='message:send').length,1);
 assert.equal(h.requests.filter(x=>x.path==='/send').length,0);
});
test('password presence uses OS idle time, not page activity',async()=>{
 const h=harness();h.bridge.getIdleSeconds=async()=>420;h.context.user={username:'Test'};await h.context.api('/api/user/presence',{idle_seconds:0});
 assert.equal(h.requests.at(-1).body.idle_seconds,420);
});

test('OAuth presence requires approval and uses OS activity without reading user input',async()=>{
 const h=harness();await h.login();await h.flush();
 await assert.rejects(h.context.api('/api/user/presence',{idle_seconds:0}),/permission/);
 assert.equal(h.requests.filter(x=>x.path==='/api/user/presence').length,0);
 h.context.oauth.scope+=' presence.write';h.bridge.getIdleSeconds=async()=>127;
 await h.context.heartbeat();
 assert.equal(h.requests.at(-1).body.idle_seconds,127);
 let resolveIdle;h.bridge.getIdleSeconds=()=>new Promise(resolve=>{resolveIdle=resolve;});
 const pending=h.context.api('/api/user/presence',{idle_seconds:0});const rejected=assert.rejects(pending,/Connection ended/);
 h.context.resetToLogin();resolveIdle(0);await rejected;
 assert.equal(h.requests.filter(x=>x.path==='/api/user/presence').length,1);
});

test('hours of inactivity keep the socket, heartbeats and hidden-window notifications running',async()=>{
 const h=harness();await h.login();await h.flush();h.context.oauth.scope+=' presence.write';
 h.context.document.hidden=true;
 h.bridge.getIdleSeconds=async()=>7200;await h.timers[1]();await h.flush();
 assert.equal(h.sockets[0].connected,true);
 const count=h.requests.length;h.timers[0]();await h.context.heartbeat();await h.flush();
 assert.ok(h.requests.slice(count).some(x=>x.event==='notifications:get'));
 assert.ok(h.requests.slice(count).some(x=>x.path==='/api/user/presence'&&x.body.idle_seconds===7200));
 assert.equal(h.notes.length,1);
 h.bridge.getIdleSeconds=async()=>0;await h.timers[1]();await h.flush();
 assert.equal(h.sockets.length,1);assert.equal(h.sockets[0].connected,true);
 assert.ok(h.requests.slice(count).some(x=>x.path==='/api/user/presence'&&x.body.idle_seconds===0));
});
test('OAuth identity is resolved from the one common member without choosing another chat participant',async()=>{
 const h=harness({memberChats:[{id:21,participants:[{id:7,username:'Self'},{id:8,username:'Friend'}]},{id:22,participants:[{id:7,username:'Self'},{id:9,username:'Other'}]}]});await h.login();await h.context.getChatState();await h.flush();
 assert.equal(h.context.user.id,7);assert.equal(h.context.user.username,'Self');assert.ok(h.stored.some(x=>x?.identity?.id===7));
 const ambiguous=harness({memberChats:[{id:21,participants:[{id:7,username:'Self'},{id:8,username:'Friend'}]}]});await ambiguous.login();await ambiguous.context.getChatState();assert.equal(ambiguous.context.user.id,undefined);
});
test('saved OAuth sessions refresh expired credentials and persist the rotated pair',async()=>{
 const h=harness({saved:{access:'old',refresh:'old-refresh',scope:'chat.read chat.send',expires:Date.now()-1000}});await h.flush();await h.flush();
 assert.equal(h.context.oauth.access,'fresh-access');assert.ok(h.stored.some(x=>x?.refresh==='fresh-refresh'));
 h.context.resetToLogin();await h.flush();assert.equal(h.context.oauth,null);assert.equal(h.sockets[0].connected,false);assert.equal(h.stored.at(-1),null);
});
