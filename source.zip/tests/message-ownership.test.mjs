import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../worker/index.js',import.meta.url),'utf8');
function harness(user){const context=vm.createContext({user,window:{},$:()=>({})});vm.runInContext(source.slice(source.indexOf('function messageIsMine'),source.indexOf('function roomTitle')),context);return context;}
test('ownership uses actual sender IDs, including renamed accounts, without confusing public agent identities',()=>{
 const h=harness({id:7,username:'NewName'});
 assert.equal(h.messageIsMine({sender_user_id:7,username:'OldName'}),true);
 assert.equal(h.messageIsMine({sender_user_id:8,account_id:7,username:'NewName'}),false);
});
test('name fallback works for demo and legacy messages while an unknown OAuth identity matches nobody',()=>{
 assert.equal(harness({username:'You'}).messageIsMine({username:'You'}),true);
 assert.equal(harness({username:'EB'}).messageIsMine({profile_username:'eb',username:'Display label'}),true);
 assert.equal(harness({username:'SocialTap account',id:null}).messageIsMine({username:'EB',sender_user_id:7}),false);
});
