import {app,safeStorage} from 'electron';
import fs from 'node:fs/promises';
import path from 'node:path';
import {io} from 'socket.io-client';
const output=path.resolve('work/desktop-diagnostic.json');
app.setName('SocialTap Blue & White');
app.setPath('userData',path.resolve('work/desktop-test-profile'));
app.whenReady().then(async()=>{
 const result={};
 try{
  const saved=JSON.parse(safeStorage.decryptString(await fs.readFile(path.resolve('work/desktop-test-profile/session.encrypted'))));
  result.scope=saved.scope;result.remainingSeconds=Math.round((saved.expires-Date.now())/1000);
  for(const route of ['/api/chats','/messages?chat_id=21','/api/account']){
   const r=await fetch('https://www.socialtap.social'+route,{headers:{Authorization:'Bearer '+saved.access},redirect:'manual'});
   result[route]={status:r.status};
   if(!r.ok){let d;try{d=await r.json();}catch{}result[route].error=d?.error;}
  }
  await new Promise(resolve=>{
   const socket=io('https://www.socialtap.social',{transports:['websocket'],auth:{access_token:saved.access},reconnection:false,timeout:10000});
   const done=()=>{socket.disconnect();resolve();};
   socket.on('connect_error',e=>{result.socketError=e.message;done();});
   socket.on('connect',()=>socket.timeout(10000).emit('messages:get',{chat_id:21},(e,ack)=>{result.socketRead={timeout:!!e,status:ack?.status,error:ack?.error||ack?.data?.error};done();}));
  });
 }catch(error){result.failure=error.message;}
 await fs.writeFile(output,JSON.stringify(result,null,2));app.quit();
});
