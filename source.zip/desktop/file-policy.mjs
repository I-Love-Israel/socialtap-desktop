import path from 'node:path';
export const MAX_FILE = 10 * 1024 * 1024;
export const safeFilename = value => {
 const name=String(value||'attachment').replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').replace(/[. ]+$/,'').slice(0,180);
 return !name||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\.|$)/i.test(name)?'attachment_'+name:name;
};
// Saving is available for every file type. Executable/script files are never launched by the app.
export const canOpenFile = name => new Set(['.pdf','.txt','.csv','.json','.log','.png','.jpg','.jpeg','.webp','.gif','.bmp','.svg','.mp3','.wav','.ogg','.m4a','.flac','.mp4','.webm','.mov','.avi','.docx','.xlsx','.pptx','.odt','.ods','.odp','.rtf','.zip']).has(path.extname(name).toLowerCase());
