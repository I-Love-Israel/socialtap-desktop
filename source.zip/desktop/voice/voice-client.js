/* Desktop voice UI. The adapter owns authenticated Socket.IO and token refresh. */
(function (global) {
  'use strict';
  const createElement=(tag,text,cls)=>{const e=document.createElement(tag);if(text)e.textContent=text;if(cls)e.className=cls;return e;};
  const describeError=error=>({NotAllowedError:'Microphone access was declined. Allow access and try again.',NotFoundError:'Connect a microphone, then try again.',NotReadableError:'The microphone is busy or unavailable.'}[error?.name]||error?.message||'The call could not connect. Please try again.');
  const validFormat=value=>value&&Number.isInteger(value.frame_samples)&&value.frame_samples>=400&&value.frame_samples<=1500&&value.frame_samples%2===0&&value.sample_rate===value.frame_samples*20&&value.frame_bytes===4+value.frame_samples/2;

  function create(adapter) {
    if(typeof adapter?.request!=='function'||typeof adapter?.on!=='function')throw new Error('A voice connection adapter is required.');
    let call=null,selection='',destroyed=false,panelMessage='',setup=false;
    const removers=[];
    const style=createElement('style');
    style.textContent='.bw-call-panel{position:fixed;right:28px;bottom:28px;z-index:50;width:360px;max-width:calc(100vw - 32px);padding:22px;background:#fff;border:1px solid #cbdcf5;border-radius:18px;box-shadow:0 15px 65px #112d6440;color:#19304f}.bw-call-panel[hidden]{display:none}.bw-call-panel h2{font-size:19px;margin:0 0 8px}.bw-call-panel p{margin:8px 0}.bw-call-panel .bw-call-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:15px}.bw-call-panel select{width:100%;padding:8px;border:1px solid #d7e1ed;border-radius:8px;background:white;color:#19304f}.bw-call-danger{background:#a6333c;color:white;border-color:#a6333c}.bw-call-note{font-size:11px;line-height:1.5;color:#617594}.bw-call-status{font-size:13px}.bw-call-panel button:disabled{opacity:.5}';
    document.head.append(style);
    const callButton=createElement('button','☎ Call','btn');callButton.type='button';callButton.setAttribute('aria-label','Start a voice call');
    const head=document.querySelector('.head');if(head)head.append(callButton);
    const panel=createElement('section','','bw-call-panel');panel.hidden=true;panel.setAttribute('role','region');panel.setAttribute('aria-label','Voice call');
    const title=createElement('h2','Voice call'),status=createElement('p','','bw-call-status');status.setAttribute('aria-live','polite');
    const note=createElement('p','Calls send your microphone audio through SocialTap’s server. Audio is not end-to-end encrypted. Only start or answer a call when you are ready to share audio.','bw-call-note');
    const micLabel=createElement('label','Microphone'),microphones=createElement('select');microphones.setAttribute('aria-label','Microphone');micLabel.append(microphones);
    const actions=createElement('div','','bw-call-actions');
    const start=createElement('button','Start call','btn primary'),answer=createElement('button','Answer','btn primary'),hangup=createElement('button','End call','btn bw-call-danger'),mute=createElement('button','Mute','btn'),resume=createElement('button','Enable audio','btn'),dismiss=createElement('button','Close','btn');
    for(const b of [start,answer,hangup,mute,resume,dismiss]){b.type='button';actions.append(b);}
    panel.append(title,status,note,micLabel,actions);document.body.append(panel);

    const supported=()=>!!(global.AudioContext&&global.AudioWorkletNode&&navigator.mediaDevices?.getUserMedia);
    const scopes=()=>new Set(String(adapter.getScopes?.()||'').split(' '));
    const permitted=()=>scopes().has('voice.call')&&scopes().has('voice.audio');
    const activeRoom=()=>Number(adapter.getActiveChat?.());
    const room=()=>adapter.getChats?.()?.find(c=>Number(c.id)===activeRoom());
    const nameOfRoom=()=>room()?.name||'this conversation';
    const canCall=()=>permitted()&&adapter.isConnected?.()&&supported()&&Number.isSafeInteger(activeRoom())&&activeRoom()>0&&(!Array.isArray(room()?.participants)||room().participants.length===2);

    async function listMicrophones() {
      if(!navigator.mediaDevices?.enumerateDevices)return;
      try {
        const devices=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='audioinput');
        if(destroyed)return;
        microphones.replaceChildren();const defaultOption=createElement('option','System default');defaultOption.value='';microphones.append(defaultOption);
        devices.filter(d=>d.deviceId&&d.deviceId!=='default').forEach((d,i)=>{const option=createElement('option',d.label||'Microphone '+(i+1));option.value=d.deviceId;microphones.append(option);});
        if(selection&&!devices.some(d=>d.deviceId===selection))selection='';microphones.value=selection;
      }catch{}
    }

    function update() {
      if(destroyed)return;
      callButton.hidden=!adapter.getScopes?.();callButton.disabled=!!call||!canCall();
      callButton.title=!permitted()?'Reconnect and allow voice calls and audio.':activeRoom()<=0?'Choose a conversation with two people.':!adapter.isConnected?.()?'Waiting for your SocialTap connection.':'Call '+nameOfRoom();
      panel.hidden=!call&&!setup&&!panelMessage;
      title.textContent=call?(call.phase==='incoming'?'Incoming call':'Voice call'):'Voice call';
      const duration=call?.connectedAt?Math.floor((Date.now()-call.connectedAt)/1000):0;
      status.textContent=call?({preparing:'Opening your microphone…',ringing:'Calling '+call.name+'…',incoming:call.name+' is calling.',answering:'Answering '+call.name+'…',connecting:'Connecting audio…',active:'Connected with '+call.name+' · '+Math.floor(duration/60)+':'+String(duration%60).padStart(2,'0')}[call.phase]||'Connecting…'):setup?'Call '+nameOfRoom()+'?':panelMessage;
      start.hidden=!setup;start.disabled=!canCall();answer.hidden=call?.phase!=='incoming';
      hangup.hidden=!call;hangup.textContent=call?.phase==='incoming'?'Decline':call?.phase==='ringing'||call?.phase==='preparing'?'Cancel':'End call';
      mute.hidden=!call?.stream;mute.textContent=call?.muted?'Unmute':'Mute';mute.setAttribute('aria-pressed',String(!!call?.muted));
      resume.hidden=!call?.context||call.context.state==='running';dismiss.hidden=!!call;
      micLabel.hidden=!setup&&!call?.stream;microphones.disabled=!!call&&call.phase!=='active'&&call.phase!=='ringing';
    }

    function clearCall(message='') {
      const old=call;call=null;setup=false;panelMessage=message;
      if(old){clearTimeout(old.deadline);clearInterval(old.ringtone);old.ringContext?.close().catch(()=>{});old.stream?.getTracks().forEach(t=>t.stop());old.pendingStream?.getTracks().forEach(t=>t.stop());for(const node of [old.input,old.capture,old.playback])try{node?.disconnect();}catch{}old.context?.close().catch(()=>{});}
      update();
    }
    function end(reason='ended',message='Call ended.') {
      const old=call;if(old?.id&&adapter.isConnected?.())adapter.request('call:end',{call_id:old.id,reason}).catch(()=>{});
      clearCall(message);
    }
    function fail(c,error){if(call===c)end('connection_issue',describeError(error));}
    function deadline(c,ms){clearTimeout(c.deadline);c.deadline=setTimeout(()=>{if(call===c)end('connection_issue',c.phase==='ringing'||c.phase==='incoming'?'No answer.':'Audio could not connect. Try again.');},ms);}

    async function acquire(c) {
      const stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,...(selection?{deviceId:{exact:selection}}:{})},video:false});
      if(call!==c){stream.getTracks().forEach(t=>t.stop());return false;}
      c.stream=stream;await listMicrophones();return true;
    }
    function formatFor(c,value) {
      if(!validFormat(value))throw new Error('SocialTap returned an unsupported audio format.');
      c.format={sample_rate:value.sample_rate,frame_samples:value.frame_samples,frame_bytes:value.frame_bytes};
    }
    async function beginAudio(c,announce) {
      if(call!==c||c.audioStarting||c.audioReady)return;
      c.audioStarting=true;c.phase='connecting';deadline(c,15000);update();
      try {
        if(c.preparing)await c.preparing;
        if(call!==c||!c.stream)return;
        if(announce)await adapter.request('call:relay:start',{call_id:c.id});
        if(call!==c)return;
        if(!validFormat(c.format))throw new Error('This call did not include its audio format.');
        c.context=new AudioContext();
        await c.context.audioWorklet.addModule(adapter.workletUrl||'/desktop/voice/relay-worklet.js');
        if(call!==c)return;
        const processorOptions={format:c.format};
        c.capture=new AudioWorkletNode(c.context,'blue-white-capture',{processorOptions});
        c.playback=new AudioWorkletNode(c.context,'blue-white-playback',{numberOfInputs:0,numberOfOutputs:1,processorOptions});
        c.input=c.context.createMediaStreamSource(c.stream);c.input.connect(c.capture);c.capture.connect(c.context.destination);c.playback.connect(c.context.destination);
        c.capture.port.onmessage=({data})=>{
          if(call!==c||!c.audioReady||!adapter.isConnected?.()||!(data instanceof ArrayBuffer)||data.byteLength!==c.format.frame_bytes)return;
          const payload={call_id:c.id,frame:data};
          if(adapter.sendAudio)Promise.resolve(adapter.sendAudio(payload)).catch(error=>{if(error?.status!==429)fail(c,error);});
          else adapter.request('call:audio',payload).catch(error=>{if(error?.status!==429)fail(c,error);});
        };
        c.audioReady=true;
        for(const frame of c.earlyFrames||[])c.playback.port.postMessage(frame,[frame]);c.earlyFrames=[];
        await c.context.resume();
        if(call!==c)return;
        await adapter.request('call:connected',{call_id:c.id});
        if(call!==c)return;
        clearTimeout(c.deadline);c.phase='active';c.connectedAt=Date.now();update();
      }catch(error){fail(c,error);}finally{c.audioStarting=false;}
    }
    function ring(c) {
      try {
        c.ringContext=new AudioContext();
        const beep=()=>{if(call!==c||c.phase!=='incoming')return;const tone=c.ringContext.createOscillator(),gain=c.ringContext.createGain();tone.frequency.value=520;gain.gain.value=.055;tone.connect(gain);gain.connect(c.ringContext.destination);tone.start();tone.stop(c.ringContext.currentTime+.22);};
        c.ringContext.resume().then(beep).catch(()=>{});c.ringtone=setInterval(beep,2000);
      }catch{}
    }
    function silenceRing(c){clearInterval(c.ringtone);c.ringContext?.close().catch(()=>{});c.ringContext=null;}

    callButton.onclick=()=>{if(canCall()&&!call){setup=true;panelMessage='';listMicrophones();update();}};
    start.onclick=async()=>{
      if(!canCall()||call)return;
      setup=false;panelMessage='';const c=call={phase:'preparing',name:nameOfRoom(),chatId:activeRoom(),muted:false,role:'caller'};deadline(c,45000);update();
      try {
        c.preparing=acquire(c);if(!await c.preparing)return;
        const result=await adapter.request('call:start',{chat_id:c.chatId});
        if(call!==c){if(result.call_id)adapter.request('call:end',{call_id:result.call_id,reason:'ended'}).catch(()=>{});return;}
        if(typeof result.call_id!=='string'||!result.call_id)throw new Error('SocialTap returned an incomplete call.');
        c.id=result.call_id;c.name=result.username||c.name;formatFor(c,result.relay_audio);c.phase='ringing';deadline(c,45000);update();
      }catch(error){fail(c,error);}
    };
    answer.onclick=async()=>{
      const c=call;if(!c||c.phase!=='incoming')return;
      c.phase='answering';silenceRing(c);deadline(c,45000);update();
      try {
        c.preparing=(async()=>{const result=await adapter.request('call:accept',{call_id:c.id});if(call!==c)return false;formatFor(c,result.relay_audio);return acquire(c);})();
        if(await c.preparing&&call===c)await beginAudio(c,true);
      }catch(error){fail(c,error);}
    };
    hangup.onclick=()=>end(call?.phase==='incoming'?'declined':'ended');
    mute.onclick=()=>{if(call?.stream){call.muted=!call.muted;call.stream.getAudioTracks().forEach(t=>{t.enabled=!call.muted;});update();}};
    resume.onclick=()=>call?.context?.resume().then(update).catch(error=>{panelMessage=describeError(error);update();});
    dismiss.onclick=()=>{setup=false;panelMessage='';update();};
    microphones.onchange=async()=>{
      selection=microphones.value;const c=call;if(!c?.stream)return;
      try {
        const next=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,...(selection?{deviceId:{exact:selection}}:{})},video:false});
        if(call!==c){next.getTracks().forEach(t=>t.stop());return;}
        c.pendingStream=next;next.getAudioTracks().forEach(t=>{t.enabled=!c.muted;});
        if(c.context&&c.capture){const source=c.context.createMediaStreamSource(next);source.connect(c.capture);c.input.disconnect();c.input=source;}
        c.stream.getTracks().forEach(t=>t.stop());c.stream=next;c.pendingStream=null;update();
      }catch(error){if(call===c){panelMessage=describeError(error);status.textContent=panelMessage;}}
    };

    const on=(event,handler)=>{const remove=adapter.on(event,handler);if(typeof remove==='function')removers.push(remove);};
    on('call:incoming',data=>{
      if(call||!permitted()||typeof data?.call_id!=='string'||!validFormat(data.relay_audio))return;
      setup=false;panelMessage='';const c=call={id:data.call_id,chatId:data.chat_id,name:data.username||'Someone',phase:'incoming',role:'recipient',muted:false,format:data.relay_audio};deadline(c,45000);ring(c);update();
      adapter.notify?.({title:'Incoming SocialTap call',body:c.name+' is calling.',chatId:Number(c.chatId)||0,kind:'call'});
    });
    on('call:claimed',data=>{if(call?.id===data?.call_id&&data.sid!==adapter.getSocketId?.())clearCall('Answered on another device.');});
    on('call:accepted',data=>{if(call?.id===data?.call_id&&call.role==='caller')beginAudio(call,true);});
    on('call:relay:start',data=>{if(call?.id===data?.call_id&&call.phase!=='incoming')beginAudio(call,false);});
    on('call:audio',data=>{
      const c=call;if(!c||data?.call_id!==c.id||!c.format)return;
      const raw=data.frame;let frame;
      if(raw instanceof ArrayBuffer)frame=raw.slice(0);else if(ArrayBuffer.isView(raw))frame=raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength);else return;
      if(frame.byteLength!==c.format.frame_bytes)return;
      if(c.audioReady)c.playback.port.postMessage(frame,[frame]);else{(c.earlyFrames??=[]).push(frame);if(c.earlyFrames.length>8)c.earlyFrames.shift();}
    });
    on('call:ended',data=>{if(call?.id===data?.call_id)clearCall(({declined:'Call declined.',no_answer:'No answer.',connection_issue:'The call ended because the connection was lost.'})[data.reason]||'Call ended.');});
    on('disconnect',()=>{if(call)clearCall('The call ended because the connection was lost.');update();});
    on('connect',update);
    const interval=setInterval(update,1000);
    const deviceChanged=()=>listMicrophones();navigator.mediaDevices?.addEventListener('devicechange',deviceChanged);
    update();
    return {update,isActive:()=>!!call,reset:()=>end('ended',''),destroy(){end('ended','');destroyed=true;clearInterval(interval);for(const remove of removers)remove();navigator.mediaDevices?.removeEventListener('devicechange',deviceChanged);callButton.remove();panel.remove();style.remove();}};
  }
  global.SocialTapVoice={create};
})(window);
