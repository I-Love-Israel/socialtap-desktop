import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
import {encodeFrame,decodeFrame,validateFormat} from './codec.mjs';

test('relay bytes match a reference vector from the deployed SocialTap codec',()=>{
  const samples=Float32Array.from({length:400},(_,i)=>Math.sin(i*2*Math.PI*440/8000)*.5);
  const encoded=encodeFrame(samples);
  assert.equal(encoded.byteLength,204);
  assert.equal(createHash('sha256').update(encoded).digest('hex'),'08333f84e3baa39b32cc78e93fc89a5cf97b6c35d204f09543e5661cf60fc20e');
  const decoded=decodeFrame(encoded,400);
  const meanError=decoded.slice(40).reduce((sum,s,i)=>sum+Math.abs(s-samples[i+40]),0)/360;
  assert.ok(meanError<.03,meanError);
});

test('all supported relay rates produce valid packets without state from prior frames',()=>{
  for(const count of [400,800,1500]){
    const format={frame_samples:count,sample_rate:count*20,frame_bytes:4+count/2};assert.deepEqual(validateFormat(format),format);
    const signal=Float32Array.from({length:count},(_,i)=>i%2?1:-1);
    const first=encodeFrame(signal);encodeFrame(new Float32Array(count));assert.deepEqual(encodeFrame(signal),first);
    assert.equal(decodeFrame(first,count).length,count);
    assert.ok([...decodeFrame(first,count)].every(n=>Number.isFinite(n)&&n>=-1&&n<=1));
  }
  assert.equal(decodeFrame(new Uint8Array(203),400),null);
  assert.throws(()=>validateFormat({frame_samples:400,sample_rate:16000,frame_bytes:204}));
  assert.throws(()=>validateFormat({frame_samples:1502,sample_rate:30040,frame_bytes:755}));
});

test('capture worklet creates twenty correctly sized packets per second at 48 kHz',()=>{
  const processors={},frames=[];
  class Base{constructor(){this.port={postMessage:frame=>frames.push(frame)};}}
  const context={AudioWorkletProcessor:Base,registerProcessor:(name,type)=>processors[name]=type,sampleRate:48000,encodeFrame,decodeFrame,validateFormat,Float32Array,Uint8Array,ArrayBuffer};
  vm.createContext(context);
  vm.runInContext(readFileSync(new URL('./relay-worklet.js',import.meta.url),'utf8').replace(/^import[^\n]+\n/,''),context);
  const capture=new processors['blue-white-capture']({processorOptions:{format:{sample_rate:8000,frame_samples:400,frame_bytes:204}}});
  for(let i=0;i<375;i++)capture.process([[new Float32Array(128).fill(.1)]]);
  assert.equal(frames.length,20);assert.ok(frames.every(f=>f.byteLength===204));
  const playback=new processors['blue-white-playback']({processorOptions:{format:{sample_rate:8000,frame_samples:400,frame_bytes:204}}});
  const out=new Float32Array(128);
  for(let i=0;i<3;i++)playback.port.onmessage({data:frames[i]});
  playback.process([],[[out]]);assert.ok(out.every(v=>v===0));
  playback.port.onmessage({data:frames[3]});playback.process([],[[out]]);assert.ok(out.some(v=>v!==0));
  for(let i=0;i<20;i++)playback.port.onmessage({data:frames[0]});assert.ok(playback.pending.length<=8);
});

function voiceHarness({scope='chat.read voice.call voice.audio',micReject=false}={}) {
  const elements=[];
  class Element {
    constructor(tag){this.tag=tag;this.children=[];this.hidden=false;this.value='';elements.push(this);}
    append(...children){this.children.push(...children);}
    setAttribute(name,value){this[name]=value;}
    replaceChildren(...children){this.children=children;}
    remove(){}
  }
  const head=new Element('head'),body=new Element('body'),header=new Element('header'),handlers={},requests=[],notes=[];
  let micCalls=0,stops=0,connected=true;
  const stream={getTracks:()=>[{stop(){stops++;}}],getAudioTracks:()=>[{enabled:true}]};
  const navigator={mediaDevices:{getUserMedia:async()=>{micCalls++;if(micReject)throw Object.assign(Error('Denied'),{name:'NotAllowedError'});return stream;},enumerateDevices:async()=>[],addEventListener(){},removeEventListener(){}}};
  class AudioContext {constructor(){this.state='running';this.destination={};this.currentTime=0;this.audioWorklet={addModule:async()=>{}};}resume(){return Promise.resolve();}close(){return Promise.resolve();}createOscillator(){return {frequency:{value:0},connect(){},start(){},stop(){}};}createGain(){return {gain:{value:0},connect(){}};}createMediaStreamSource(){return {connect(){},disconnect(){}};}}
  class AudioWorkletNode {constructor(){this.port={postMessage(){}};}connect(){}disconnect(){}}
  const context={window:null,document:{head,body,querySelector:()=>header,createElement:tag=>new Element(tag)},navigator,AudioContext,AudioWorkletNode,ArrayBuffer,Uint8Array,Promise,Date,Number,Set,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,clearInterval(){}};context.window=context;vm.createContext(context);vm.runInContext(readFileSync(new URL('./voice-client.js',import.meta.url),'utf8'),context);
  const format={sample_rate:8000,frame_samples:400,frame_bytes:204};
  const adapter={request:async(event,payload)=>{requests.push({event,payload});return {success:true,call_id:'test-call',username:'Peer',relay_audio:format};},on:(e,fn)=>{handlers[e]=fn;return ()=>delete handlers[e];},getSocketId:()=> 'own-socket',getScopes:()=>scope,getActiveChat:()=>21,getChats:()=>[{id:21,name:'Peer',participants:[{},{}]}],isConnected:()=>connected,notify:data=>notes.push(data)};
  const client=context.SocialTapVoice.create(adapter);
  const button=text=>elements.find(e=>e.tag==='button'&&e.textContent===text);
  return {client,handlers,requests,notes,button,adapter,format,get micCalls(){return micCalls;},get stops(){return stops;},disconnect(){connected=false;handlers.disconnect();}};
}

test('incoming calls notify but do not capture microphone before Answer; Decline sends only call:end',()=>{
  const h=voiceHarness();h.handlers['call:incoming']({call_id:'incoming',chat_id:21,username:'Peer',relay_audio:h.format});
  assert.equal(h.micCalls,0);assert.equal(h.notes.length,1);assert.ok(h.client.isActive());
  h.button('Decline').onclick();assert.equal(h.micCalls,0);assert.equal(h.requests.length,1);assert.equal(h.requests[0].event,'call:end');assert.equal(h.requests[0].payload.reason,'declined');assert.equal(h.client.isActive(),false);
});

test('microphone denial does not place an outgoing call',async()=>{
  const h=voiceHarness({micReject:true});h.button('☎ Call').onclick();await h.button('Start call').onclick();
  assert.equal(h.micCalls,1);assert.equal(h.requests.length,0);assert.equal(h.client.isActive(),false);
});

test('answer requires a user action and a disconnect stops microphone tracks',async()=>{
  const h=voiceHarness();h.handlers['call:incoming']({call_id:'incoming',chat_id:21,username:'Peer',relay_audio:h.format});
  await h.button('Answer').onclick();assert.equal(h.micCalls,1);assert.deepEqual(h.requests.map(r=>r.event),['call:accept','call:relay:start','call:connected']);
  h.disconnect();assert.equal(h.stops,1);assert.equal(h.client.isActive(),false);
});

test('declined voice.audio scope disables calling and ignores incoming audio requests',()=>{
  const h=voiceHarness({scope:'chat.read voice.call'});assert.equal(h.button('☎ Call').disabled,true);
  h.handlers['call:incoming']({call_id:'incoming',chat_id:21,username:'Peer',relay_audio:h.format});assert.equal(h.client.isActive(),false);assert.equal(h.notes.length,0);assert.equal(h.micCalls,0);
});
