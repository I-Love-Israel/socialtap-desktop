// SocialTap relay wire format: independent mono IMA ADPCM packets, 50 ms each.
// Four reserved zero bytes precede low-nibble-first codes; state resets per packet.
const stepSizes = [7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,66,73,80,88,97,107,118,130,143,157,173,190,209,230,253,279,307,337,371,408,449,494,544,598,658,724,796,876,963,1060,1166,1282,1411,1552,1707,1878,2066,2272,2499,2749,3024,3327,3660,4026,4428,4871,5358,5894,6484,7132,7845,8630,9493,10442,11487,12635,13899,15289,16818,18500,20350,22385,24623,27086,29794,32767];
const indexChanges = [-1,-1,-1,-1,2,4,6,8];
const bounded = (n,lo,hi) => Math.min(hi,Math.max(lo,n));

export function validateFormat(value) {
  if (!value || !Number.isInteger(value.frame_samples) || value.frame_samples < 400 || value.frame_samples > 1500 || value.frame_samples % 2 || value.sample_rate !== value.frame_samples * 20 || value.frame_bytes !== value.frame_samples / 2 + 4) throw new Error('SocialTap returned an unsupported audio format.');
  return {sample_rate:value.sample_rate,frame_samples:value.frame_samples,frame_bytes:value.frame_bytes};
}

function advance(state,code) {
  const step=stepSizes[state.index];
  const delta=(step>>3)+(code&4?step:0)+(code&2?step>>1:0)+(code&1?step>>2:0);
  state.value=bounded(state.value+(code&8?-delta:delta),-32768,32767);
  state.index=bounded(state.index+indexChanges[code&7],0,88);
  return state.value;
}

export function encodeFrame(samples) {
  if (!samples || !Number.isInteger(samples.length) || samples.length%2) throw new Error('Audio packets require an even sample count.');
  const bytes=new Uint8Array(4+samples.length/2),state={value:0,index:0};
  for(let i=0;i<samples.length;i++) {
    const sample=bounded(Math.round((Number.isFinite(samples[i])?samples[i]:0)*32767),-32768,32767);
    let magnitude=sample-state.value,code=magnitude<0?8:0;
    magnitude=Math.abs(magnitude);
    const step=stepSizes[state.index];
    for(const [bit,threshold] of [[4,step],[2,step>>1],[1,step>>2]]) {
      if(magnitude>=threshold){code|=bit;magnitude-=threshold;}
    }
    advance(state,code);
    bytes[4+(i>>1)]|=code<<((i%2)*4);
  }
  return bytes;
}

export function decodeFrame(input,count) {
  const bytes=input instanceof Uint8Array?input:input instanceof ArrayBuffer?new Uint8Array(input):null;
  if(!bytes || !Number.isInteger(count) || count%2 || bytes.byteLength!==4+count/2) return null;
  const samples=new Float32Array(count),state={value:0,index:0};
  for(let i=0;i<count;i++) samples[i]=advance(state,(bytes[4+(i>>1)]>>((i%2)*4))&15)/32768;
  return samples;
}
