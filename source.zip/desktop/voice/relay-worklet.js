import {encodeFrame,decodeFrame,validateFormat} from './codec.mjs';

class BlueWhiteCapture extends AudioWorkletProcessor {
  constructor(options) {
    super();
    this.format=validateFormat(options.processorOptions.format);
    this.packet=new Float32Array(this.format.frame_samples);
    this.offset=0;this.phase=0;this.total=0;this.inputCount=0;
  }
  process(inputs) {
    const input=inputs[0];
    if(!input?.length)return true;
    for(let i=0;i<input[0].length;i++) {
      let mono=0;for(const channel of input)mono+=channel[i]/input.length;
      this.total+=mono;this.inputCount++;
      this.phase+=this.format.sample_rate;
      if(this.phase>=sampleRate) {
        const value=this.total/this.inputCount;
        this.total=0;this.inputCount=0;
        while(this.phase>=sampleRate) {
          this.phase-=sampleRate;this.packet[this.offset++]=value;
          if(this.offset===this.packet.length) {
            const bytes=encodeFrame(this.packet);
            this.port.postMessage(bytes.buffer,[bytes.buffer]);this.offset=0;
          }
        }
      }
    }
    return true;
  }
}

class BlueWhitePlayback extends AudioWorkletProcessor {
  constructor(options) {
    super();this.format=validateFormat(options.processorOptions.format);
    this.pending=[];this.packet=null;this.offset=0;this.ready=false;
    this.port.onmessage=({data})=>{
      const decoded=decodeFrame(data,this.format.frame_samples);
      if(!decoded)return;
      this.pending.push(decoded);
      if(this.pending.length>8)this.pending.shift();
    };
  }
  process(_inputs,outputs) {
    const channels=outputs[0];if(!channels?.length)return true;
    const target=channels[0];
    for(let i=0;i<target.length;i++) {
      if(!this.ready&&this.pending.length>=4)this.ready=true;
      if(!this.packet&&this.ready) {
        this.packet=this.pending.shift()||null;
        if(!this.packet){this.ready=false;this.offset=0;}
      }
      target[i]=this.packet?this.packet[Math.floor(this.offset)]:0;
      if(this.packet){this.offset+=this.format.sample_rate/sampleRate;if(this.offset>=this.packet.length){this.offset-=this.packet.length;this.packet=null;}}
    }
    for(let i=1;i<channels.length;i++)channels[i].set(target);
    return true;
  }
}

registerProcessor('blue-white-capture',BlueWhiteCapture);
registerProcessor('blue-white-playback',BlueWhitePlayback);
