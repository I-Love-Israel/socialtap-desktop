// Keep native toasts alive after the main window hides. No chat text is included.
export function createNotifier({Notification,getWindow,enabled,icon,onClick}) {
 const active=new Set();
 return async data=>{
  if(!enabled()||!Notification.isSupported()||!data||typeof data.title!=='string')return false;
  const win=getWindow();
  if(data.kind!=='test'&&data.kind!=='call'&&win?.isVisible()&&win?.isFocused())return false;
  const notification=new Notification({title:data.title.slice(0,100),body:String(data.body||'New activity in SocialTap').slice(0,200),icon,silent:data.kind!=='call',timeoutType:'default',groupId:'socialtap-messages'});
  active.add(notification);if(active.size>100)active.delete(active.values().next().value);
  notification.on('close',()=>active.delete(notification));
  notification.on('click',()=>onClick(data.chatId));
  return new Promise(resolve=>{
   let settled=false;const finish=shown=>{if(settled)return;settled=true;clearTimeout(timer);resolve(shown);};
   const timer=setTimeout(()=>finish(false),5000);
   notification.once('show',()=>finish(true));
   notification.once('failed',()=>{active.delete(notification);finish(false);});
   try{notification.show();}catch{active.delete(notification);finish(false);}
  });
 };
}
