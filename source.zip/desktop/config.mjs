export const CLIENT_ID='stu_LiuJtKyxFx69AXy1uceZw_jrxTyKjqPh9-PP3fSS9S8';
export const LOCAL_ORIGIN='http://127.0.0.1:4317';
export const ISSUER='https://www.socialtap.social';
export const REDIRECT=LOCAL_ORIGIN+'/oauth/callback';
export const SCOPES=['chat.read','chat.send','voice.call','account.read','voice.audio','presence.write'];
export function validAuthorization(value){
 try{
  if(typeof value!=='string'||value.length>4096)return null;
  const u=new URL(value),p=u.searchParams;
  if(u.origin!==ISSUER||u.pathname!=='/api/oauth/authorize'||u.hash||u.username||u.password)return null;
  if([...p.keys()].some(k=>p.getAll(k).length!==1))return null;
  if(p.get('client_id')!==CLIENT_ID||p.get('redirect_uri')!==REDIRECT||p.get('response_type')!=='code'||p.get('code_challenge_method')!=='S256')return null;
  if(!/^[A-Za-z0-9_-]{43}$/.test(p.get('state')||'')||!/^[A-Za-z0-9_-]{43}$/.test(p.get('code_challenge')||''))return null;
  const scopes=(p.get('scope')||'').split(' ');
  if(scopes.some(s=>!SCOPES.includes(s))||!['chat.read','chat.send','voice.call'].every(s=>scopes.includes(s)))return null;
  return {url:u.href,state:p.get('state'),created:Date.now()};
 }catch{return null;}
}
export function validCallback(search,pending){
 const p=new URLSearchParams(search);
 if(!pending||Date.now()-pending.created>600000||Date.now()<pending.created||p.getAll('state').length!==1||p.get('state')!==pending.state)return false;
 if(p.has('error'))return p.getAll('error').length===1;
 return p.getAll('iss').length===1&&p.get('iss')===ISSUER&&p.getAll('code').length===1&&!!p.get('code');
}
