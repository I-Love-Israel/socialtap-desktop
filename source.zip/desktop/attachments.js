/* Browser-only attachment controls. Sending always requires the composer submit. */
(() => {
 'use strict';
 const bridge=window.socialtapDesktop;if(!bridge)return;
 const MAX=10*1024*1024, drafts=new Map(), urls=new Set();
 const originalRender=renderMessages,originalSelect=select,originalReset=resetToLogin,originalSubmit=$('composer').onsubmit;
 let sending=false;
 const element=(tag,text,cls)=>{const n=document.createElement(tag);if(text)n.textContent=text;if(cls)n.className=cls;return n;};
 const bytesLabel=n=>n>=1048576?(n/1048576).toFixed(1)+' MB':Math.ceil(n/1024)+' KB';
 const bar=element('div',null,'attachment-bar'),list=element('div'),pick=element('button','Attach files','btn'),input=element('input');
 pick.type='button';input.type='file';input.multiple=true;input.hidden=true;pick.onclick=()=>input.click();bar.append(pick,input,list);$('composer').prepend(bar);
 const hint=element('div','Files up to 10 MB each · You can also drag files here.','info');bar.append(hint);
 const css=element('style');css.textContent='.attachment-bar{padding:8px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap}.attachment-bar>div{display:flex;gap:6px;flex-wrap:wrap}.attachment-card{margin-top:9px;padding:12px;border:1px solid #c7d7ef;border-radius:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;max-width:560px}.attachment-card strong{overflow-wrap:anywhere;flex:1 1 180px}.attachment-card .info{flex-basis:100%}.attachment-preview{max-width:min(78vw,800px);max-height:70vh}.attachment-preview img,.attachment-preview video{max-width:100%;max-height:60vh}.attachment-preview pre{white-space:pre-wrap;overflow-wrap:anywhere;max-height:60vh;overflow:auto}.file-chip{border-radius:8px;background:#edf3ff;padding:6px;font-size:12px}.file-chip button{margin-left:8px}.attachment-drop{outline:3px dashed #2764cc}';document.head.append(css);
 function paint(){
  list.replaceChildren();pick.disabled=!user||demo||active===null||sending||!!(oauth&&!oauth.scope.split(' ').includes('chat.send'));
  for(const f of drafts.get(active)||[]){const item=element('span',f.name+' · '+bytesLabel(f.size),'file-chip'),remove=element('button','×');remove.type='button';remove.setAttribute('aria-label','Remove '+f.name);remove.disabled=sending;remove.onclick=()=>{drafts.set(active,(drafts.get(active)||[]).filter(x=>x!==f));paint();};item.append(remove);list.append(item);}
 }
 function add(files){
  if(!user||demo||active===null||sending)return;
  const selected=drafts.get(active)||[];
  for(const file of files){if(!file.size||file.size>MAX){errors.action=file.name+': choose a nonempty file of 10 MB or smaller.';continue;}if(selected.length>=10){errors.action='Send up to 10 files at a time.';break;}selected.push(file);}
  drafts.set(active,selected);paint();paintStatus();
 }
 input.onchange=()=>{add(input.files);input.value='';};
 document.addEventListener('dragover',e=>{if(e.dataTransfer?.types.includes('Files')){e.preventDefault();$('composer').classList.add('attachment-drop');}});
 document.addEventListener('dragleave',()=>{$('composer').classList.remove('attachment-drop');});
 document.addEventListener('drop',e=>{e.preventDefault();$('composer').classList.remove('attachment-drop');if(e.dataTransfer?.files)add(e.dataTransfer.files);});
 async function fileRequest(route,{body,version=authVersion}={}){
  const usingOAuth=!!oauth;
  if(usingOAuth&&Date.now()>=oauth.expires-30000)await refreshAccess();
  if(version!==authVersion)throw Error('Connection changed.');
  const send=()=>fetch('/bridge'+route,{method:body?'POST':'GET',headers:usingOAuth&&oauth?{Authorization:'Bearer '+oauth.access}:{},body,signal:AbortSignal.timeout(95000)});
  const token=oauth?.access;let response;
  try{response=await send();}catch{throw Error(body?'Upload was not confirmed. Check the conversation before sending again.':'Download failed. Please try again.');}
  if(response.status===401&&usingOAuth&&oauth&&version===authVersion){if(oauth.access===token)await refreshAccess();if(version!==authVersion)throw Error('Connection changed.');response=await send();}
  if(version!==authVersion)throw Error('Connection changed.');
  if(!response.ok){let data;try{data=await response.json();}catch{}throw Error(data?.error||'Attachment request failed ('+response.status+').');}
  return response;
 }
 $('composer').onsubmit=async e=>{
  const chosen=[...(drafts.get(active)||[])];if(!chosen.length)return originalSubmit(e);
  e.preventDefault();if(sending||!user||demo||active===null||oauth&&!oauth.scope.split(' ').includes('chat.send'))return;
  const id=active,version=authVersion,caption=$('text').value.trim();sending=true;paint();$('send').disabled=true;
  let sent=0;
  try{
   for(const file of chosen){
    const delay=Math.max(0,2100-(Date.now()-lastSent));if(delay)await new Promise(resolve=>setTimeout(resolve,delay));
    if(version!==authVersion)throw Error('Connection changed.');
    const form=new FormData();form.set('file',file);form.set('chat_id',String(id));form.set('message',sent===0?caption:'');
    const response=await fileRequest('/attachments',{body:form,version});
    const result=await response.json();if(result.error||result.success===false)throw Error(result.error||'Upload did not complete.');
    if(version===authVersion&&result.message?.sender_user_id&&typeof learnOwnIdentity==='function')learnOwnIdentity(result.message);
    lastSent=Date.now();sent++;drafts.set(id,(drafts.get(id)||[]).filter(x=>x!==file));
    if(active===id&&version===authVersion){if(sent===1&&$('text').value.trim()===caption){$('text').value='';$('text').dispatchEvent(new Event('input'));}paint();await load();}
   }
   if(version===authVersion)errors.action='';
  }catch(error){if(version===authVersion)errors.action=(sent?'Sent '+sent+' file(s). ':'')+error.message;}
  finally{sending=false;paint();$('send').disabled=!user||active===null||!!(oauth&&!oauth.scope.split(' ').includes('chat.send'));paintStatus();}
 };
 function mediaType(file){
  const ext=String(file.filename||'').split('.').pop().toLowerCase();
  return ({webp:'image/webp',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',mp3:'audio/mpeg',wav:'audio/wav',ogg:'audio/ogg',m4a:'audio/mp4',flac:'audio/flac',mp4:'video/mp4',webm:'video/webm',mov:'video/quicktime'})[ext]||'';
 }
 async function download(file){
  if(!/^[A-Za-z0-9_-]{1,128}$/.test(String(file.id)))throw Error('Invalid attachment.');
  const response=await fileRequest('/attachments/'+encodeURIComponent(file.id));const bytes=new Uint8Array(await response.arrayBuffer());
  if(!bytes.length||bytes.length>MAX)throw Error('This attachment is empty or too large.');return bytes;
 }
 async function preview(file){
  const version=authVersion,bytes=await download(file);if(version!==authVersion)return;
  const type=mediaType(file),dialog=element('dialog',null,'attachment-preview'),close=element('button','Close','btn');close.type='button';
  dialog.append(element('h3',file.filename||'Attachment'));let url;
  if(type){url=URL.createObjectURL(new Blob([bytes],{type}));urls.add(url);const media=element(type.startsWith('image/')?'img':type.startsWith('audio/')?'audio':'video');media.src=url;media.alt=file.filename||'Attachment';if(media.tagName!=='IMG')media.controls=true;dialog.append(media);}
  else dialog.append(element('pre',new TextDecoder().decode(bytes.slice(0,100000))+(bytes.length>100000?'\n[Preview shortened. Save to read the whole file.]':'')));
  const dismiss=()=>{if(url){URL.revokeObjectURL(url);urls.delete(url);}dialog.remove();};close.onclick=()=>dialog.close();dialog.addEventListener('close',dismiss,{once:true});dialog.append(close);document.body.append(dialog);dialog.showModal();
 }
 renderMessages=function(){
  originalRender();const rows=[...$('messages').querySelectorAll('.message')];
  messages.forEach((message,index)=>{
   const file=message.attachment;if(!file||!rows[index])return;
   const card=element('div',null,'attachment-card'),name=String(file.filename||'Attachment'),notice=element('div',bytesLabel(Number(file.size)||0),'info');
   card.append(element('strong',name),notice);rows[index].querySelector('.bubble').append(card);
   const unavailable=file.removed?'This attachment was removed.':file.restricted?'This attachment is restricted.':file.expired?'This attachment has expired.':null;
   if(unavailable){notice.textContent=unavailable;return;}
   const action=(label,fn)=>{const b=element('button',label,'btn');b.type='button';b.onclick=async()=>{b.disabled=true;try{await fn();}catch(error){notice.textContent=error.message;}finally{b.disabled=false;}};card.append(b);};
   const type=mediaType(file);if(type||/\.(txt|csv|json|log|md)$/i.test(name))action('Preview',()=>preview(file));
   for(const [label,open]of[['Open',true],['Save',false]])action(label,async()=>{const version=authVersion,bytes=await download(file);if(version!==authVersion)return;const result=await bridge.saveFile({name,bytes,open});if(result.saved)notice.textContent=result.opened?'Opened in your default app.':open?'Saved. You can open it from its folder.':'Saved.';});
  });paint();
 };
 select=async function(id){await originalSelect(id);paint();};
 resetToLogin=function(...args){drafts.clear();for(const url of urls)URL.revokeObjectURL(url);urls.clear();document.querySelectorAll('.attachment-preview').forEach(x=>x.remove());originalReset(...args);paint();};
 paint();
})();
