const {contextBridge,ipcRenderer}=require('electron');
const listen=(channel,fn)=>{const handler=(_event,data)=>fn(data);ipcRenderer.on(channel,handler);return()=>ipcRenderer.removeListener(channel,handler);};
contextBridge.exposeInMainWorld('socialtapDesktop',Object.freeze({
 authorize:url=>ipcRenderer.invoke('desktop:authorize',url),
 onOAuthCallback:fn=>listen('desktop:oauth-callback',fn),
 setOAuthStatus:status=>ipcRenderer.send('desktop:oauth-status',status),
 getIdleSeconds:()=>ipcRenderer.invoke('desktop:idle'),
 saveFile:data=>ipcRenderer.invoke('desktop:save-file',data),
 getSettings:()=>ipcRenderer.invoke('desktop:settings'),
 onSettingsChanged:fn=>listen('desktop:settings-changed',fn),
 updateSettings:patch=>ipcRenderer.invoke('desktop:update-settings',patch),
 notify:data=>ipcRenderer.invoke('desktop:notify',data),
 onNotificationClick:fn=>listen('desktop:notification-click',fn),
 saveSession:value=>ipcRenderer.invoke('desktop:save-session',value),
 loadSession:()=>ipcRenderer.invoke('desktop:load-session'),
 clearSession:()=>ipcRenderer.invoke('desktop:clear-session')
}));
