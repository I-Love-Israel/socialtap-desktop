const UPSTREAM = 'https://www.socialtap.social';
export const MAX_FILE = 10 * 1024 * 1024;
export const MAX_UPLOAD = MAX_FILE + 65536;
export const attachmentPath = path => /^\/attachments\/[A-Za-z0-9_-]{1,128}$/.test(path);
const error = (message, status) => Response.json({error:message}, {status,headers:{'Cache-Control':'no-store'}});

export async function attachmentRequest(req, fetcher=fetch) {
  const url = new URL(req.url), route = url.pathname.slice('/bridge'.length);
  const upload = route === '/attachments' && req.method === 'POST';
  if (!upload && !(attachmentPath(route) && req.method === 'GET')) return error('Unsupported attachment request.',405);
  if (url.search) return error('Attachment queries are not supported.',400);
  if (upload && req.headers.get('origin') !== url.origin) return error('Invalid origin.',403);
  const headers = new Headers({Origin:UPSTREAM,Referer:UPSTREAM+'/'});
  const bearer = req.headers.get('authorization');
  const session = (req.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('st_session='));
  if (bearer) {
    if (!/^Bearer [A-Za-z0-9._~+\/-]+=*$/.test(bearer)) return error('Invalid authorization.',401);
    headers.set('Authorization',bearer);
  } else if (session) headers.set('Cookie','session='+session.slice(11));
  else return error('Please sign in to SocialTap.',401);
  try {
    let body, rotatedSession;
    if (upload) {
      if (!req.headers.get('content-type')?.startsWith('multipart/form-data;')) return error('Select a file to attach.',415);
      if (Number(req.headers.get('content-length')||0)>MAX_UPLOAD) return error('Files must be 10 MB or smaller.',413);
      const incoming = await req.formData(), file = incoming.get('file');
      if (!(file instanceof Blob) || !file.size || file.size>MAX_FILE) return error('Choose a nonempty file of 10 MB or smaller.',413);
      const chatId = incoming.get('chat_id'), message = incoming.get('message')||'';
      if (typeof chatId!=='string'||!/^\d+$/.test(chatId)||!Number.isSafeInteger(Number(chatId))) return error('Invalid conversation.',400);
      if (typeof message!=='string'||message.length>500) return error('Captions must be 500 characters or fewer.',400);
      body = new FormData(); body.set('file',file,String(file.name||'attachment').slice(0,255)); body.set('chat_id',chatId); body.set('message',message);
      if (!bearer) {
        // The session-only friends response supplies its CSRF token. Friend data
        // is neither forwarded nor stored by this upload route.
        const csrf = await fetcher(UPSTREAM+'/api/friends',{headers,redirect:'manual',signal:AbortSignal.timeout(20000)});
        if (!csrf.ok) return error('Please sign in again before uploading.',csrf.status===401?401:502);
        const data=await csrf.json(); if(typeof data.csrf_token!=='string') return error('SocialTap did not provide an upload token.',502);
        body.set('csrf_token',data.csrf_token);
        rotatedSession=csrf.headers.getSetCookie().find(x=>x.startsWith('session='));
        if(rotatedSession)headers.set('Cookie',rotatedSession.split(';')[0]);
      }
    }
    const response = await fetcher(UPSTREAM+route,{method:req.method,headers,body,redirect:'manual',signal:AbortSignal.timeout(90000)});
    if(response.status>=300&&response.status<400) return error('Please sign in again.',401);
    if(!response.ok) {
      let message = ({401:'Please sign in again.',403:'This conversation does not allow this attachment.',404:'This attachment is not available.',410:'This attachment expired or was removed.',413:'This file exceeds SocialTap’s size limit.',423:'This attachment is restricted.'})[response.status]||'SocialTap could not complete the attachment request.';
      if(response.headers.get('content-type')?.includes('json')){try{const data=await response.json();if(typeof data.error==='string')message=data.error.slice(0,300);}catch{}}
      return error(message,response.status);
    }
    const output = new Headers({'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"sandbox; default-src 'none'"});
    if(upload) {
      if(!response.headers.get('content-type')?.includes('json'))return error('Upload result was not recognized. Check the conversation before retrying.',502);
      output.set('Content-Type','application/json');
    } else {
      const type=response.headers.get('content-type')||'application/octet-stream';
      output.set('Content-Type',type==='image/webp'?'image/webp':'application/octet-stream');
      output.set('Content-Disposition','attachment');
    }
    if(!bearer) for(const cookie of [...(rotatedSession?[rotatedSession]:[]),...response.headers.getSetCookie()]) {
      if(cookie.startsWith('session='))output.append('Set-Cookie',cookie.split(';')[0].replace(/^session=/,'st_session=')+'; Path=/; SameSite=Strict; HttpOnly');
    }
    const bytes=await response.arrayBuffer();
    if(bytes.byteLength>MAX_UPLOAD)return error('Attachment is too large.',413);
    return new Response(bytes,{status:response.status,headers:output});
  } catch {return error(upload?'Upload was not confirmed. Check the conversation before trying again.':'Could not download the attachment. Please try again.',502);}
}
