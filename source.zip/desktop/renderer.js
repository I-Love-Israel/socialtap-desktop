/* Desktop additions run in the same isolated, browser-only world as the client. */
(() => {
  'use strict';
  const bridge = window.socialtapDesktop;
  if (!bridge) return;
  const httpApi = api, originalStart = start, originalReset = resetToLogin;
  const originalRefresh = refreshAccess, originalState = getChatState, originalSelect = select;
  let socket = null, socketVersion = -1, boundToken = null, recovering = null;
  let notificationsSince = null, notificationBusy = false, lastRecovery = 0;
  let settings = { notifications: true, startup: true, closeToTray: true, darkMode: true };
  let idleSeconds = 0, previousIdle = 0, idleBusy = false, accountVersion = -1;
  let voice = null, stopped = false, persistenceError = '';
  const handlers = new Map();
  const scopes = () => oauth?.scope || '';
  const hasScope = scope => scopes().split(' ').includes(scope);
  const chatScopeCompatibility = error => error?.status === 403 && error.message === 'insufficient_scope';
  const node = (tag, text, className) => {
    const result = document.createElement(tag);
    if (text) result.textContent = text;
    if (className) result.className = className;
    return result;
  };

  const button = node('button', 'Desktop settings', 'btn');
  button.type = 'button'; button.id = 'desktop-settings-button';
  document.querySelector('.top').append(button);
  const themeButton = node('button', 'Use light mode', 'btn');
  themeButton.type = 'button'; themeButton.id = 'theme-toggle';
  document.querySelector('.top').append(themeButton);
  themeButton.onclick = async () => {
    themeButton.disabled = true;
    try { settings = await bridge.updateSettings({ darkMode: !settings.darkMode }); paintSettings(); }
    catch { settingsError.textContent = 'Could not save your theme. Please try again.'; }
    finally { themeButton.disabled = false; }
  };
  const desktopStatus = node('div', '', 'status');
  desktopStatus.id = 'desktop-status';
  $('title').parentElement.append(desktopStatus);
  const dialog = node('dialog'); dialog.id = 'desktop-settings';
  dialog.append(node('h2', 'Desktop settings'));
  const controls = {};
  for (const [key, label] of [
    ['notifications', 'Show Windows notifications'],
    ['startup', 'Start with Windows'],
    ['darkMode', 'Dark mode'],
  ]) {
    const row = node('label'); const input = node('input');
    input.type = 'checkbox'; input.style.width = 'auto'; input.id = 'desktop-' + key;
    controls[key] = input; row.append(input, document.createTextNode(' ' + label)); dialog.append(row);
    input.onchange = async () => {
      input.disabled = true;
      try { settings = await bridge.updateSettings({ [key]: input.checked }); paintSettings(); }
      catch { settingsError.textContent = 'Could not save this preference. Please try again.'; input.checked = !!settings[key]; }
      finally { input.disabled = false; }
    };
  }
  const idleNote = node('p', '', 'info');
  const sessionNote = node('p', 'Your connection is stored encrypted on this Windows account. Disconnect removes it.', 'info');
  const settingsError = node('p', '', 'error'); settingsError.setAttribute('role', 'status');
  const testNotification = node('button', 'Test notification', 'btn'); testNotification.type = 'button';
  testNotification.onclick = async () => {
    testNotification.disabled = true;
    try { const shown = await bridge.notify({ title: 'SocialTap', body: 'Desktop notifications are ready.', kind: 'test', chatId: 0 });
      settingsError.textContent = shown ? 'Notification sent to Windows. If no banner appears, check Windows notification settings and Do not disturb.' : 'Windows could not show the notification. Check that SocialTap notifications are enabled.';
    } finally { testNotification.disabled = false; }
  };
  const close = node('button', 'Done', 'btn primary'); close.type = 'button'; close.onclick = () => dialog.close();
  const actions = node('div', '', 'actions'); actions.append(testNotification, close);
  dialog.append(idleNote, sessionNote, settingsError, actions); document.body.append(dialog);
  button.onclick = () => { paintSettings(); dialog.showModal(); };

  function paintSettings() {
    document.documentElement?.setAttribute('data-theme', settings.darkMode ? 'dark' : 'light');
    themeButton.textContent = settings.darkMode ? 'Use light mode' : 'Use dark mode';
    themeButton.setAttribute('aria-pressed', String(!!settings.darkMode));
    for (const key of Object.keys(controls)) controls[key].checked = !!settings[key];
    settingsError.textContent = persistenceError;
    idleNote.textContent = oauth && !hasScope('presence.write')
      ? 'SocialTap stays connected while idle and when the window is closed. Reconnect with idle-status access if you want to share Windows activity. Choose Quit from the tray menu to exit.'
      : 'SocialTap stays connected while idle and when the window is closed. Windows activity updates your status without disconnecting you. Choose Quit from the tray menu to exit.';
  }
  function paintDesktopStatus() {
    const connection = demo ? 'Local demo' : oauth ? (socket?.connected ? 'Connected' : 'Reconnecting · reading messages is available') : user ? 'Password connection' : 'Desktop ready';
    const idle = idleSeconds >= 300 ? 'Windows idle · ' + Math.floor(idleSeconds / 60) + 'm' : 'Windows active';
    desktopStatus.textContent = connection + ' · ' + idle + (oauth && !hasScope('presence.write') ? ' (local status)' : '');
    paintSettings(); voice?.update();
  }
  bridge.getSettings().then(value => { settings = value; paintSettings(); }).catch(() => {
    settingsError.textContent = 'Could not load desktop preferences.';
  });
  bridge.onSettingsChanged?.(value => { settings = value; paintSettings(); });
  window.socialtapIdentityChanged = () => { persistSession(); renderMessages(); };

  async function persistSession() {
    if (!oauth) return;
    const current = oauth;
    try {
      const saved = await bridge.saveSession({ access: current.access, refresh: current.refresh, expires: current.expires, scope: current.scope, identity: user?.id ? {id:Number(user.id),username:user.username} : null });
      persistenceError = saved === false ? 'Windows could not save this connection securely. You will need to reconnect after quitting.' : '';
    } catch { persistenceError = 'Windows could not save this connection securely. You will need to reconnect after quitting.'; }
    paintSettings();
  }
  refreshAccess = async function () {
    const access = await originalRefresh();
    if (oauth) { if (socket) socket.auth = authorizeSocket; await persistSession(); }
    return access;
  };
  async function freshToken() {
    if (!oauth) throw Error('Please reconnect to SocialTap.');
    if (Date.now() >= oauth.expires - 30000) await refreshAccess();
    if (!oauth) throw Error('Please reconnect to SocialTap.');
    return oauth.access;
  }
  function authorizeSocket(done) {
    const version = authVersion;
    freshToken().then(access => {
      if (version !== authVersion || !oauth) return done({});
      boundToken = access; done({ access_token: access });
    }).catch(() => done({}));
  }
  function subscribe(event, listener) {
    if (!handlers.has(event)) handlers.set(event, new Set());
    handlers.get(event).add(listener); socket?.on(event, listener);
    return () => { handlers.get(event)?.delete(listener); socket?.off(event, listener); };
  }
  function disconnectSocket() {
    voice?.reset();
    if (socket) { socket.removeAllListeners(); socket.disconnect(); socket = null; }
    socketVersion = -1; boundToken = null; notificationsSince = null;
    accountVersion = -1; recovering = null;
  }
  function ensureSocket() {
    if (!oauth || demo || !user || stopped) return;
    if (socket && socketVersion === authVersion) return;
    disconnectSocket(); socketVersion = authVersion;
    socket = io('http://127.0.0.1:4317', {
      transports: ['websocket'], auth: authorizeSocket, autoConnect: false,
      reconnection: true, reconnectionDelay: 1000, reconnectionDelayMax: 10000, timeout: 10000,
    });
    for (const [event, listeners] of handlers) for (const listener of listeners) socket.on(event, listener);
    socket.on('connect', () => { paintDesktopStatus(); load(); pollNotifications(); });
    socket.on('chat:changed', () => { pollNotifications(); if (!document.hidden) load(); });
    socket.on('disconnect', () => paintDesktopStatus());
    socket.on('connect_error', error => {
      paintDesktopStatus();
      const unauthorized = Number(error?.data?.status) === 401 || /token|expired|unauthor/i.test(String(error?.message || ''));
      if (unauthorized && Date.now() - lastRecovery > 30000) recoverAuthorization().catch(() => {});
    });
    socket.connect(); paintDesktopStatus();
  }
  async function recoverAuthorization() {
    if (recovering) return recovering;
    const version = authVersion, currentSocket = socket;
    lastRecovery = Date.now();
    const task = (async () => {
      if (!oauth || !currentSocket) throw Error('Please reconnect to SocialTap.');
      if (oauth.access === boundToken) await refreshAccess();
      if (version !== authVersion || currentSocket !== socket || !oauth) throw Error('Connection ended.');
      await new Promise((resolve, reject) => {
        const timer = setTimeout(() => done(Error('SocialTap could not reconnect. Please try again.')), 20000);
        const connected = () => done();
        const failed = () => done(Error('SocialTap could not reconnect. Please try again.'));
        function done(error) { clearTimeout(timer); currentSocket.off('connect', connected); currentSocket.off('connect_error', failed); error ? reject(error) : resolve(); }
        currentSocket.once('connect', connected); currentSocket.once('connect_error', failed);
        currentSocket.auth = authorizeSocket; currentSocket.disconnect(); currentSocket.connect();
      });
    })();
    recovering = task;
    try { await task; } finally { if (recovering === task) recovering = null; }
  }
  function emitAck(event, payload) {
    const target = socket;
    if (!target?.connected) { const error = Error('The live connection is recovering. Please try again.'); error.transport = true; return Promise.reject(error); }
    return new Promise((resolve, reject) => {
      target.timeout(event === 'call:audio' ? 5000 : 12000).emit(event, payload, (timeout, ack) => {
        if (timeout) {
          const error = Error(event === 'message:send' ? 'Message delivery was not confirmed. Check the conversation before sending again.' : 'The live connection did not respond.');
          error.transport = true; error.uncertain = true; reject(error); return;
        }
        if (!ack || Number(ack.status) < 200 || Number(ack.status) >= 300) {
          const error = Error(String(ack?.error || ack?.data?.error || 'SocialTap could not complete this request.'));
          error.status = Number(ack?.status) || 0; reject(error); return;
        }
        resolve(ack.data);
      });
    });
  }
  async function request(event, payload) {
    const version = authVersion;
    await freshToken();
    if (version !== authVersion) throw Error('Connection ended.');
    try { return await emitAck(event, payload); }
    catch (error) {
      if (error.status !== 401 || !oauth || version !== authVersion) throw error;
      await recoverAuthorization();
      // An explicit 401 did not execute the operation. Audio frames are always discarded.
      if (event === 'call:audio') throw error;
      if (version !== authVersion) throw Error('Connection ended.');
      return emitAck(event, payload);
    }
  }
  api = async function (path, body, form) {
    if (path === '/api/user/presence' && body) {
      const version = authVersion;
      if (oauth && !hasScope('presence.write')) {
        const error = Error('Reconnect with permission to share your idle status.'); error.status = 403; throw error;
      }
      const actual = await bridge.getIdleSeconds();
      if (version !== authVersion) throw Error('Connection ended.');
      const result = await httpApi(path, { idle_seconds: Math.max(0, Math.min(2147483647, Math.floor(Number(actual) || 0))) }, form);
      if (version === authVersion) learnOwnIdentity({user_id:result.user_id});
      return result;
    }
    if (oauth && !demo && path.startsWith('/messages?')) {
      const version = authVersion, query = new URLSearchParams(path.split('?')[1]);
      if (socket?.connected) {
        try { return await request('messages:get', { chat_id: Number(query.get('chat_id')) || 0, ...(query.has('last_id') ? { last_id: Number(query.get('last_id')) || 0 } : {}) }); }
        catch (error) { if ((!error.transport && !chatScopeCompatibility(error)) || version !== authVersion) throw error; }
      }
      return httpApi(path, body, form);
    }
    if (oauth && !demo && path === '/send') {
      const version = authVersion;
      try { return await request('message:send', { chat_id: Number(body.chat_id) || 0, message: body.message }); }
      catch (error) {
        // A scope-denied acknowledgement did not send a message. The HTTP API
        // applies the same account checks and currently accepts this valid grant.
        if (version !== authVersion || !chatScopeCompatibility(error) || !hasScope('chat.send')) throw error;
        return httpApi(path, body, form);
      }
    }
    return httpApi(path, body, form);
  };

  async function readAccount() {
    if (!oauth || !hasScope('account.read') || accountVersion === authVersion) return;
    const version = authVersion;
    try {
      const result = await httpApi('/api/account');
      if (!oauth || version !== authVersion) return;
      const account = result.account || result.user || result.profile || result;
      if (typeof account.username === 'string' && account.username.trim()) user.username = account.username;
      const id = Number(account.id ?? account.user_id ?? account.userId);
      if (Number.isSafeInteger(id) && id > 0) user.id = id;
      accountVersion = version;
    } catch { /* Chats remain usable if an optional profile response is unavailable. */ }
  }
  getChatState = async function () {
    const version = authVersion;
    const result = await originalState();
    if (version !== authVersion) throw Error('Connection changed.');
    if (!Number.isSafeInteger(Number(user?.id)) || Number(user?.id) <= 0) {
      const members = result.chats.filter(chat => Number(chat.id)>0 && Array.isArray(chat.participants) && chat.participants.length).map(chat => chat.participants);
      if (members.length) {
        const common = members[0].filter(person => Number(person.id)>0 && members.every(group => group.some(other => Number(other.id)===Number(person.id))));
        if (common.length===1) learnOwnIdentity(common[0]);
      }
    }
    if (oauth && hasScope('account.read')) {
      const preferences = await httpApi('/api/settings');
      if (typeof preferences.enable_global_chat === 'boolean') result.globalEnabled = preferences.enable_global_chat;
    }
    return result;
  };
  start = async function () {
    if (oauth && !demo) { ensureSocket(); await readAccount(); await persistSession(); }
    await originalStart(); paintDesktopStatus(); heartbeat();
  };
  select = async function (id) { await originalSelect(id); voice?.update(); };
  resetToLogin = function (...args) {
    disconnectSocket();
    bridge.clearSession().catch(() => {});
    originalReset(...args); paintDesktopStatus();
  };

  async function pollNotifications() {
    if (!user || demo || notificationBusy || stopped) return;
    notificationBusy = true; const version = authVersion;
    try {
      const since = notificationsSince ?? 0;
      let result;
      if (oauth && socket?.connected) {
        try { result = await request('notifications:get', { since }); }
        catch (error) { if ((!error.transport && !chatScopeCompatibility(error)) || version !== authVersion) throw error; }
      }
      if (!result) result = await httpApi('/api/notifications?since=' + since);
      if (version !== authVersion || !user || !Array.isArray(result.updates)) return;
      const next = Number(result.since);
      if (!Number.isSafeInteger(next) || next < 0) return;
      const bootstrapping = notificationsSince === null;
      notificationsSince = Math.max(since, next);
      if (!bootstrapping && settings.notifications) for (const update of result.updates) {
        const count = Number(update.new_messages), chatId = update.chat_id === null ? 0 : Number(update.chat_id);
        if (!Number.isSafeInteger(count) || count <= 0 || !Number.isSafeInteger(chatId) || chatId < 0) continue;
        const chatName = chatId === 0 ? 'Global Chat' : chats.find(chat => chat.id === chatId)?.name;
        bridge.notify({ title: chatName ? 'SocialTap · ' + chatName : 'SocialTap', body: count === 1 ? 'You have a new message.' : 'You have ' + count + ' new messages.', chatId, kind: 'message' });
      }
    } catch { /* Background retry waits for the next poll; existing chat status handles failures. */ }
    finally { notificationBusy = false; }
  }
  bridge.onNotificationClick(async chatId => {
    if (!user) return;
    const id = Number(chatId);
    if (!Number.isSafeInteger(id) || id < 0) return;
    const version = authVersion;
    try { if (id > 0 && !chats.some(chat => chat.id === id)) await syncState();
      if (version === authVersion && (id === 0 && globalEnabled || chats.some(chat => chat.id === id))) await select(id);
    } catch { /* The opened window displays the normal connection error. */ }
  });
  async function updateIdle() {
    if (idleBusy || stopped) return; idleBusy = true;
    const version = authVersion;
    try {
      idleSeconds = Math.max(0, Math.min(2147483647, Math.floor(Number(await bridge.getIdleSeconds()) || 0)));
      if (version !== authVersion) return;
      if (version === authVersion && previousIdle >= 300 && idleSeconds < 300 && user && !demo && (!oauth || hasScope('presence.write'))) await api('/api/user/presence', { idle_seconds: idleSeconds });
      previousIdle = idleSeconds; paintDesktopStatus();
    } catch { desktopStatus.textContent = 'Windows idle status is temporarily unavailable.'; }
    finally { idleBusy = false; }
  }
  // The original heartbeat still calls api(); its body is replaced with actual OS idle time above.
  heartbeat = async function () { if (user && !demo && (!oauth || hasScope('presence.write'))) try { await api('/api/user/presence', { idle_seconds: idleSeconds }); } catch {} };
  if (window.SocialTapVoice) voice = window.SocialTapVoice.create({
    request, sendAudio: payload => request('call:audio', payload), on: subscribe,
    getSocketId: () => socket?.id || '', getActiveChat: () => active, getChats: () => chats,
    getScopes: scopes, isConnected: () => !!socket?.connected,
    notify: value => bridge.notify({ ...value, kind: 'call' }), workletUrl: '/desktop/voice/relay-worklet.js',
  });
  const pollTimer = setInterval(() => { ensureSocket(); pollNotifications(); }, 5000);
  const idleTimer = setInterval(updateIdle, 5000);
  const presenceTimer = setInterval(() => { if (oauth) heartbeat(); }, 60000);
  updateIdle(); paintDesktopStatus();
  window.addEventListener('beforeunload', () => {
    stopped = true; clearInterval(pollTimer); clearInterval(idleTimer); clearInterval(presenceTimer); voice?.destroy();
    if (socket) { socket.removeAllListeners(); socket.disconnect(); }
  });
  const restoreVersion = authVersion;
  bridge.loadSession().then(async saved => {
    if (!saved || oauth || user || demo || authVersion !== restoreVersion || sessionStorage.getItem(pendingKey)) return;
    if (typeof saved.access !== 'string' || !saved.access || typeof saved.refresh !== 'string' || !saved.refresh || typeof saved.scope !== 'string' || !saved.scope.split(' ').includes('chat.read') || !Number.isFinite(saved.expires)) {
      await bridge.clearSession(); return;
    }
    oauth = { access: saved.access, refresh: saved.refresh, expires: saved.expires, scope: saved.scope };
    authVersion++; user = { username: 'SocialTap account', id: null }; demo = false;
    if (saved.identity && Number.isSafeInteger(saved.identity.id) && saved.identity.id>0 && typeof saved.identity.username==='string') user = {id:saved.identity.id,username:saved.identity.username};
    bridge.setOAuthStatus({ connected: true });
    try { await freshToken(); await start(); }
    catch (error) { if (oauth) resetToLogin(error.message || 'Please reconnect to SocialTap.'); }
  }).catch(() => { persistenceError = 'Could not restore your saved connection. Please sign in.'; paintSettings(); });
})();
