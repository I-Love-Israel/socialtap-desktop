import http from 'node:http';
import fs from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import crypto from 'node:crypto';
import {WebSocket,WebSocketServer} from 'ws';
import worker from './worker.mjs';
import {LOCAL_ORIGIN} from './config.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const files=new Map([
 ['/desktop/socket.io.js',['node_modules/socket.io-client/dist/socket.io.min.js','text/javascript']],
 ['/desktop/renderer.js',['renderer.js','text/javascript']],
 ['/desktop/voice/voice-client.js',['voice/voice-client.js','text/javascript']],
 ['/desktop/voice/relay-worklet.js',['voice/relay-worklet.js','text/javascript']],
 ['/desktop/voice/codec.mjs',['voice/codec.mjs','text/javascript']]
]);
const same=(a,b)=>typeof a==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&crypto.timingSafeEqual(Buffer.from(a),Buffer.from(b));
const hasCapability=(req,capability)=>same((req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('st_desktop='))?.slice(11),capability);
export async function startServer({capability,onCallback,port=4317}){
 const server=http.createServer(async(req,res)=>{
  const end=(status,body)=>{res.writeHead(status,{'Content-Type':'text/plain','Cache-Control':'no-store'});res.end(body);};
  try{
   if(req.headers.host!=='127.0.0.1:4317')return end(403,'Invalid address');
   const u=new URL(req.url,LOCAL_ORIGIN);
   if(u.pathname==='/oauth/callback'&&req.method==='GET'){
    const ok=onCallback(u.search);
    res.writeHead(ok?200:400,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'"});
    return res.end('<!doctype html><html><title>SocialTap Blue & White</title><body style="font:18px system-ui;max-width:620px;margin:15vh auto;color:#19304f;padding:30px"><h1>'+(ok?'Return to Blue & White':'Sign-in link not accepted')+'</h1><p>'+(ok?'Your sign-in has returned to the desktop app. You can close this browser tab.':'Open Blue & White and choose Connect with SocialTap again.')+'</p></body></html>');
   }
   const cookie=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('st_desktop='))?.slice(11);
   if(!same(cookie,capability))return end(403,'Open SocialTap Blue & White from the Windows app.');
   if(req.headers.origin&&req.headers.origin!==LOCAL_ORIGIN)return end(403,'Invalid origin');
   if(!['GET','POST','HEAD'].includes(req.method))return end(405,'Unsupported request');
   if(files.has(u.pathname)&&req.method==='GET'){
    const [file,type]=files.get(u.pathname);res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});return res.end(await fs.readFile(path.join(root,file)));
   }
   const chunks=[];let length=0;for await(const c of req){length+=c.length;if(length>32768)return end(413,'Request too large');chunks.push(c);}
   const headers={...req.headers};delete headers.host;
   const response=await worker.fetch(new Request(LOCAL_ORIGIN+u.pathname+u.search,{method:req.method,headers,...(['GET','HEAD'].includes(req.method)?{}:{body:Buffer.concat(chunks)})}));
   const output=Object.fromEntries(response.headers),cookies=response.headers.getSetCookie();if(cookies.length)output['set-cookie']=cookies;
   let body=Buffer.from(await response.arrayBuffer());
   if(response.headers.get('content-type')?.includes('text/html')){
    body=Buffer.from(body.toString().replace('</body>','<script src="/desktop/socket.io.js"></script><script src="/desktop/voice/voice-client.js"></script><script src="/desktop/renderer.js"></script></body>'));
    const script=body.toString().match(/<script>([\s\S]*?)<\/script>/)?.[1]||'';
    const hash=crypto.createHash('sha256').update(script).digest('base64');
    output['content-security-policy']="default-src 'none'; script-src 'self' 'sha256-"+hash+"'; style-src 'unsafe-inline'; img-src 'self' data:; connect-src 'self' ws://127.0.0.1:4317; media-src 'self' blob:; worker-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'";
   }
   res.writeHead(response.status,output);res.end(req.method==='HEAD'?undefined:body);
  }catch{if(!res.headersSent)end(500,'The app could not complete this request.');else res.end();}
 });
 const sockets=new Set(),tunnel=new WebSocketServer({noServer:true,maxPayload:2*1024*1024});
 server.on('upgrade',(req,stream,head)=>{
  const u=new URL(req.url,LOCAL_ORIGIN);
  if(req.headers.host!=='127.0.0.1:4317'||req.headers.origin!==LOCAL_ORIGIN||!hasCapability(req,capability)||u.pathname!=='/socket.io/'||u.searchParams.get('EIO')!=='4'||u.searchParams.get('transport')!=='websocket'){
   stream.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');return;
  }
  // This native connection has no browser Origin header. Tokens stay inside
  // Socket.IO's authentication frame; the remote URL is fixed and has no secrets.
  const remote=new WebSocket('wss://www.socialtap.social/socket.io/?EIO=4&transport=websocket',{handshakeTimeout:10000,maxPayload:2*1024*1024});
  sockets.add(remote);let local;
  const close=()=>{sockets.delete(remote);remote.terminate();local?.terminate();stream.destroy();};
  remote.on('error',close);remote.on('close',close);stream.on('error',close);stream.on('close',()=>{if(!local)close();});
  remote.on('open',()=>tunnel.handleUpgrade(req,stream,head,client=>{
   local=client;
   client.on('message',(data,binary)=>{if(remote.readyState===WebSocket.OPEN)remote.send(data,{binary});});
   client.on('error',close);client.on('close',close);
  }));
  remote.on('message',(data,binary)=>{if(local?.readyState===WebSocket.OPEN)local.send(data,{binary});});
 });
 server.on('close',()=>{for(const socket of sockets)socket.terminate();tunnel.close();});
 server.requestTimeout=30000;server.headersTimeout=10000;
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
 return server;
}
