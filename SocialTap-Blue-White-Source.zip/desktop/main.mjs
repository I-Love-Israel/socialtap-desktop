import {app,BrowserWindow,Menu,Tray,nativeImage,shell,ipcMain,Notification,powerMonitor,session,dialog,safeStorage,screen} from 'electron';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
import {startServer} from './server.mjs';
import {LOCAL_ORIGIN,ISSUER,validAuthorization,validCallback} from './config.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const testProfile=process.argv.find(x=>x.startsWith('--profile-dir='))?.slice(14);
if(testProfile)app.setPath('userData',testProfile);
app.setName('SocialTap Blue & White');app.setAppUserModelId('socialtap.bluewhite.desktop');
let win,tray,server,pending=null,quitting=false,connected=false;
let settings={notifications:true,startup:true,closeToTray:true};
let lastNotification=0;
let sessionWrites=Promise.resolve();
const sessionWrite=fn=>{const result=sessionWrites.then(fn);sessionWrites=result.catch(()=>{});return result;};
const settingsPath=()=>path.join(app.getPath('userData'),'preferences.json');
const tokenPath=()=>path.join(app.getPath('userData'),'session.encrypted');
const show=()=>{if(win&&!win.isDestroyed()){win.show();if(win.isMinimized())win.restore();win.focus();}};
const trusted=event=>event.sender===win?.webContents&&event.senderFrame===win?.webContents.mainFrame&&new URL(event.senderFrame.url).origin===LOCAL_ORIGIN;
const handle=(name,fn)=>ipcMain.handle('desktop:'+name,async(event,...args)=>{if(!trusted(event))throw Error('Untrusted app request');return fn(...args);});
function startup(){
 if(!app.isPackaged||testProfile)return;
 const exe=process.env.PORTABLE_EXECUTABLE_FILE||process.execPath;
 app.setLoginItemSettings({openAtLogin:settings.startup,path:exe,args:['--hidden']});
}
async function saveSettings(){await fs.mkdir(app.getPath('userData'),{recursive:true});await fs.writeFile(settingsPath(),JSON.stringify(settings));startup();buildMenu();}
function buildMenu(){
 const startupEntry={label:'Start with Windows',type:'checkbox',checked:settings.startup,click:async item=>{settings.startup=item.checked;await saveSettings();}};
 const notificationEntry={label:'Desktop notifications',type:'checkbox',checked:settings.notifications,click:async item=>{settings.notifications=item.checked;await saveSettings();}};
 const items=[{label:'Open Blue & White',click:show},notificationEntry,startupEntry,{type:'separator'},{label:'Quit',click:()=>{quitting=true;app.quit();}}];
 tray?.setContextMenu(Menu.buildFromTemplate(items));
 Menu.setApplicationMenu(Menu.buildFromTemplate([{label:'Blue & White',submenu:[{label:'Show window',click:show},notificationEntry,startupEntry,{label:'Keep running when closed',type:'checkbox',checked:settings.closeToTray,click:async item=>{settings.closeToTray=item.checked;await saveSettings();}},{type:'separator'},{label:'Quit',accelerator:'Alt+F4',click:()=>{quitting=true;app.quit();}}]},{label:'Edit',submenu:[{role:'undo'},{role:'redo'},{type:'separator'},{role:'cut'},{role:'copy'},{role:'paste'},{role:'selectAll'}]},{label:'View',submenu:[{role:'resetZoom'},{role:'zoomIn'},{role:'zoomOut'},{role:'togglefullscreen'}]}]));
}
function safeExternal(value){try{const u=new URL(value);return u.protocol==='https:'&&u.hostname==='www.socialtap.social'&&!u.username&&!u.password;}catch{return false;}}
if(!app.requestSingleInstanceLock()){app.quit();}else{
 app.on('second-instance',show);app.on('activate',show);
 app.on('before-quit',()=>{quitting=true;pending=null;server?.close();tray?.destroy();});
 app.on('window-all-closed',()=>{if(!tray)app.quit();});
 app.whenReady().then(async()=>{
  try{
   try{const stored=JSON.parse(await fs.readFile(settingsPath(),'utf8'));for(const k of Object.keys(settings))if(typeof stored[k]==='boolean')settings[k]=stored[k];}catch{}
   const capability=crypto.randomBytes(32).toString('hex');
   server=await startServer({capability,onCallback:search=>{if(!validCallback(search,pending))return false;pending=null;show();win?.webContents.send('desktop:oauth-callback',search);return true;}});
   const partition='persist:blue-white';const ses=session.fromPartition(partition);
   await ses.cookies.set({url:LOCAL_ORIGIN,name:'st_desktop',value:capability,httpOnly:true,sameSite:'strict',path:'/'});
   ses.setPermissionRequestHandler((contents,permission,callback,details)=>{const local=contents===win?.webContents&&new URL(contents.getURL()).origin===LOCAL_ORIGIN;callback(local&&permission==='media'&&details.mediaTypes?.every(x=>x==='audio'));});
   ses.setPermissionCheckHandler((contents,permission,requestOrigin)=>contents===win?.webContents&&requestOrigin===LOCAL_ORIGIN&&permission==='media');
   const display=screen.getPrimaryDisplay().workAreaSize;
   win=new BrowserWindow({title:'SocialTap Blue & White',width:Math.min(1280,display.width),height:Math.min(850,display.height),minWidth:640,minHeight:420,show:false,backgroundColor:'#f8faff',icon:path.join(root,'assets/icon.ico'),webPreferences:{partition,preload:path.join(root,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true,backgroundThrottling:false}});
   win.webContents.on('will-navigate',(event,url)=>{if(new URL(url).origin!==LOCAL_ORIGIN){event.preventDefault();if(safeExternal(url))shell.openExternal(url);}});
   win.webContents.setWindowOpenHandler(({url})=>{if(safeExternal(url))shell.openExternal(url);return {action:'deny'};});
   win.on('close',event=>{if(!quitting&&settings.closeToTray){event.preventDefault();win.hide();}});
   win.webContents.on('render-process-gone',()=>{connected=false;tray?.setToolTip('Blue & White · reopen to reconnect');});
   const icon=nativeImage.createFromPath(path.join(root,'assets/icon.ico'));tray=new Tray(icon);tray.setToolTip('SocialTap Blue & White');tray.on('double-click',show);tray.on('click',show);
   handle('authorize',async value=>{const next=validAuthorization(value);if(!next)throw Error('Invalid SocialTap sign-in request');pending=next;try{await shell.openExternal(next.url);return true;}catch{pending=null;throw Error('Could not open your browser.');}});
   ipcMain.on('desktop:oauth-status',(event,value)=>{if(trusted(event)){connected=value?.connected===true;tray.setToolTip('Blue & White · '+(connected?'Connected':'Sign in to connect'));}});
   handle('idle',()=>Math.min(2147483647,Math.max(0,powerMonitor.getSystemIdleTime())));
   handle('settings',()=>({...settings}));
   handle('update-settings',async patch=>{for(const k of Object.keys(settings))if(typeof patch?.[k]==='boolean')settings[k]=patch[k];await saveSettings();return {...settings};});
   handle('notify',data=>{
    if(!settings.notifications||!Notification.isSupported()||!data||typeof data.title!=='string')return false;
    if(data.kind!=='test'&&data.kind!=='call'&&win.isVisible()&&win.isFocused())return false;
    if(Date.now()-lastNotification<1500)return false;lastNotification=Date.now();
    const n=new Notification({title:data.title.slice(0,100),body:String(data.body||'New activity in SocialTap').slice(0,200),icon:path.join(root,'assets/icon.ico'),silent:data.kind!=='call'});
    n.on('click',()=>{show();if(Number.isSafeInteger(data.chatId)&&data.chatId>=0)win.webContents.send('desktop:notification-click',data.chatId);});n.show();return true;
   });
   handle('save-session',value=>sessionWrite(async()=>{
    if(!safeStorage.isEncryptionAvailable())return false;
    if(!value||!['access','refresh','scope'].every(k=>typeof value[k]==='string')||value.access.length>8192||value.refresh.length>8192||!Number.isFinite(value.expires))throw Error('Invalid session');
    const clean={access:value.access,refresh:value.refresh,expires:value.expires,scope:value.scope};
    await fs.mkdir(app.getPath('userData'),{recursive:true});await fs.writeFile(tokenPath(),safeStorage.encryptString(JSON.stringify(clean)));return true;
   }));
   handle('load-session',async()=>{await sessionWrites;try{if(!safeStorage.isEncryptionAvailable())return null;return JSON.parse(safeStorage.decryptString(await fs.readFile(tokenPath())));}catch{return null;}});
   handle('clear-session',()=>sessionWrite(async()=>{await fs.rm(tokenPath(),{force:true});return true;}));
   await saveSettings();await win.loadURL(LOCAL_ORIGIN+'/');if(!process.argv.includes('--hidden'))show();
  }catch(error){dialog.showErrorBox('Blue & White could not open',error.code==='EADDRINUSE'?'Port 4317 is already in use. Close another Blue & White window or local preview, then try again.':String(error.message||'Please try opening the app again.'));quitting=true;app.quit();}
 });
}
